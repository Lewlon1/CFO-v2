import { useState, useEffect } from "react";

const PHASES = [
  {
    id: "overview",
    label: "Strategy overview",
    icon: "◈",
    technique: null,
  },
  {
    id: "values",
    label: "Values & vision",
    icon: "◇",
    technique: "Priority ranking",
    description: "Drag-rank what matters most to you. This shapes every recommendation I'll make.",
    why: "Your values determine whether I recommend aggressive growth or stable preservation, experiences over assets, freedom over security.",
  },
  {
    id: "cashflow",
    label: "Income & cash flow",
    icon: "△",
    technique: "Structured capture",
    description: "Map your money in and money out — recurring and irregular.",
    why: "Without knowing your actual cash flow, any advice is guesswork. This is the foundation.",
  },
  {
    id: "assets",
    label: "Assets & debts",
    icon: "□",
    technique: "Balance sheet builder",
    description: "Build a snapshot of everything you own and everything you owe.",
    why: "Net worth is the scoreboard. Understanding your current position sets the baseline for every goal.",
  },
  {
    id: "goals",
    label: "Goals & targets",
    icon: "○",
    technique: "Goal architect",
    description: "Define what you're working toward — with real numbers and real timelines.",
    why: "Vague goals get vague results. We'll make them specific enough to actually track and achieve.",
  },
  {
    id: "behavior",
    label: "Spending behavior",
    icon: "⬡",
    technique: "Self-assessment",
    description: "Understand your patterns, triggers, and relationship with money.",
    why: "The best budget in the world fails if it fights your psychology. We'll work with your nature, not against it.",
  },
  {
    id: "summary",
    label: "Your data brief",
    icon: "✦",
    technique: null,
  },
];

const VALUES_LIST = [
  { id: "security", label: "Financial security", desc: "Emergency fund, insurance, stable income" },
  { id: "freedom", label: "Freedom & flexibility", desc: "Work optionality, location independence" },
  { id: "experiences", label: "Experiences", desc: "Travel, dining, culture, adventure" },
  { id: "family", label: "Family & legacy", desc: "Children, inheritance, family support" },
  { id: "growth", label: "Wealth growth", desc: "Investing, compound returns, net worth" },
  { id: "comfort", label: "Daily comfort", desc: "Nice home, good food, quality of life" },
  { id: "generosity", label: "Generosity", desc: "Charitable giving, helping others" },
  { id: "earlyretire", label: "Early retirement", desc: "FIRE, financial independence" },
];

const INCOME_CATEGORIES = [
  { id: "salary", label: "Salary / wages", placeholder: "e.g. 3,500" },
  { id: "freelance", label: "Freelance / side income", placeholder: "e.g. 800" },
  { id: "investments", label: "Investment income", placeholder: "e.g. 200" },
  { id: "rental", label: "Rental income", placeholder: "e.g. 0" },
  { id: "other_income", label: "Other income", placeholder: "e.g. 100" },
];

const EXPENSE_CATEGORIES = [
  { id: "housing", label: "Housing (rent/mortgage)", placeholder: "e.g. 1,200" },
  { id: "utilities", label: "Utilities & bills", placeholder: "e.g. 250" },
  { id: "transport", label: "Transport", placeholder: "e.g. 300" },
  { id: "groceries", label: "Groceries & food", placeholder: "e.g. 400" },
  { id: "subscriptions", label: "Subscriptions & memberships", placeholder: "e.g. 80" },
  { id: "insurance", label: "Insurance", placeholder: "e.g. 150" },
  { id: "dining", label: "Dining & entertainment", placeholder: "e.g. 200" },
  { id: "shopping", label: "Shopping & personal", placeholder: "e.g. 150" },
  { id: "health", label: "Health & fitness", placeholder: "e.g. 80" },
  { id: "other_exp", label: "Other expenses", placeholder: "e.g. 100" },
];

const ASSET_TYPES = [
  { id: "cash", label: "Cash & savings", placeholder: "e.g. 15,000" },
  { id: "stocks", label: "Stocks & shares", placeholder: "e.g. 8,000" },
  { id: "retirement", label: "Pension / retirement", placeholder: "e.g. 25,000" },
  { id: "crypto", label: "Crypto", placeholder: "e.g. 2,000" },
  { id: "property", label: "Property value", placeholder: "e.g. 200,000" },
  { id: "other_asset", label: "Other assets", placeholder: "e.g. 5,000" },
];

const DEBT_TYPES = [
  { id: "mortgage", label: "Mortgage", placeholder: "e.g. 180,000", ratePlaceholder: "e.g. 4.5" },
  { id: "student", label: "Student loans", placeholder: "e.g. 20,000", ratePlaceholder: "e.g. 5.0" },
  { id: "credit", label: "Credit cards", placeholder: "e.g. 3,000", ratePlaceholder: "e.g. 19.9" },
  { id: "car", label: "Car loan", placeholder: "e.g. 8,000", ratePlaceholder: "e.g. 6.5" },
  { id: "personal", label: "Personal loans", placeholder: "e.g. 0", ratePlaceholder: "e.g. 7.0" },
  { id: "other_debt", label: "Other debt", placeholder: "e.g. 0", ratePlaceholder: "e.g. 5.0" },
];

const BEHAVIOR_QUESTIONS = [
  { id: "impulse", label: "How often do you make impulse purchases?", low: "Rarely", high: "Very often" },
  { id: "tracking", label: "How closely do you track your spending?", low: "Not at all", high: "Every penny" },
  { id: "risk", label: "How comfortable are you with investment risk?", low: "Very cautious", high: "High risk OK" },
  { id: "stress", label: "How much does money stress you out?", low: "Very calm", high: "Very stressed" },
  { id: "planning", label: "How far ahead do you financially plan?", low: "Week by week", high: "Years ahead" },
  { id: "discipline", label: "How disciplined is your saving habit?", low: "Inconsistent", high: "Very disciplined" },
];

function parseNum(s) {
  if (!s) return 0;
  return parseFloat(String(s).replace(/,/g, "")) || 0;
}

function fmt(n) {
  return n.toLocaleString("en-GB", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function DragRanker({ items, ranked, setRanked }) {
  const [dragIdx, setDragIdx] = useState(null);
  const [overIdx, setOverIdx] = useState(null);

  const unranked = items.filter((i) => !ranked.includes(i.id));

  function addItem(id) {
    setRanked([...ranked, id]);
  }

  function removeItem(id) {
    setRanked(ranked.filter((r) => r !== id));
  }

  function onDragStart(e, idx) {
    setDragIdx(idx);
    e.dataTransfer.effectAllowed = "move";
  }

  function onDragOver(e, idx) {
    e.preventDefault();
    setOverIdx(idx);
  }

  function onDrop(e, idx) {
    e.preventDefault();
    if (dragIdx === null) return;
    const newRanked = [...ranked];
    const [moved] = newRanked.splice(dragIdx, 1);
    newRanked.splice(idx, 0, moved);
    setRanked(newRanked);
    setDragIdx(null);
    setOverIdx(null);
  }

  function moveUp(idx) {
    if (idx === 0) return;
    const n = [...ranked];
    [n[idx - 1], n[idx]] = [n[idx], n[idx - 1]];
    setRanked(n);
  }

  function moveDown(idx) {
    if (idx === ranked.length - 1) return;
    const n = [...ranked];
    [n[idx], n[idx + 1]] = [n[idx + 1], n[idx]];
    setRanked(n);
  }

  return (
    <div>
      <div style={{ marginBottom: "1.5rem" }}>
        <div style={{ fontSize: 13, color: "var(--color-text-secondary)", marginBottom: 8 }}>
          Your priority order (drag to reorder, or use arrows)
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {ranked.map((id, idx) => {
            const item = items.find((i) => i.id === id);
            return (
              <div
                key={id}
                draggable
                onDragStart={(e) => onDragStart(e, idx)}
                onDragOver={(e) => onDragOver(e, idx)}
                onDrop={(e) => onDrop(e, idx)}
                onDragEnd={() => { setDragIdx(null); setOverIdx(null); }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "10px 14px",
                  background: overIdx === idx && dragIdx !== null ? "var(--color-background-info)" : "var(--color-background-primary)",
                  border: "0.5px solid var(--color-border-tertiary)",
                  borderRadius: "var(--border-radius-md)",
                  cursor: "grab",
                  transition: "background 0.15s",
                }}
              >
                <span style={{
                  fontSize: 13, fontWeight: 500, color: "var(--color-text-info)",
                  minWidth: 22, textAlign: "center"
                }}>
                  {idx + 1}
                </span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{item.label}</div>
                  <div style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>{item.desc}</div>
                </div>
                <div style={{ display: "flex", gap: 4 }}>
                  <button onClick={() => moveUp(idx)} style={{
                    padding: "2px 6px", fontSize: 12, background: "transparent",
                    border: "0.5px solid var(--color-border-tertiary)", borderRadius: 4, cursor: "pointer",
                    color: "var(--color-text-secondary)"
                  }}>↑</button>
                  <button onClick={() => moveDown(idx)} style={{
                    padding: "2px 6px", fontSize: 12, background: "transparent",
                    border: "0.5px solid var(--color-border-tertiary)", borderRadius: 4, cursor: "pointer",
                    color: "var(--color-text-secondary)"
                  }}>↓</button>
                  <button onClick={() => removeItem(id)} style={{
                    padding: "2px 6px", fontSize: 12, background: "transparent",
                    border: "0.5px solid var(--color-border-tertiary)", borderRadius: 4, cursor: "pointer",
                    color: "var(--color-text-danger)"
                  }}>×</button>
                </div>
              </div>
            );
          })}
          {ranked.length === 0 && (
            <div style={{ padding: "2rem", textAlign: "center", color: "var(--color-text-tertiary)", fontSize: 13, border: "1px dashed var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)" }}>
              Click items below to add them to your priority list
            </div>
          )}
        </div>
      </div>
      {unranked.length > 0 && (
        <div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", marginBottom: 8 }}>
            Available values — click to add
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {unranked.map((item) => (
              <button
                key={item.id}
                onClick={() => addItem(item.id)}
                style={{
                  padding: "8px 14px",
                  background: "var(--color-background-secondary)",
                  border: "0.5px solid var(--color-border-tertiary)",
                  borderRadius: "var(--border-radius-md)",
                  cursor: "pointer",
                  fontSize: 13,
                  color: "var(--color-text-primary)",
                  transition: "all 0.15s",
                }}
              >
                + {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function NumberInput({ value, onChange, placeholder, prefix = "£", suffix = "" }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 0 }}>
      {prefix && (
        <span style={{
          fontSize: 13, color: "var(--color-text-secondary)", padding: "0 8px 0 0",
          minWidth: 16,
        }}>{prefix}</span>
      )}
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{ flex: 1, minWidth: 0, fontSize: 14 }}
      />
      {suffix && (
        <span style={{ fontSize: 12, color: "var(--color-text-secondary)", padding: "0 0 0 6px" }}>{suffix}</span>
      )}
    </div>
  );
}

function SliderQuestion({ question, value, onChange }) {
  return (
    <div style={{ marginBottom: "1.25rem" }}>
      <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 8 }}>{question.label}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <span style={{ fontSize: 12, color: "var(--color-text-secondary)", minWidth: 80, textAlign: "right" }}>{question.low}</span>
        <input
          type="range"
          min="1"
          max="10"
          step="1"
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value))}
          style={{ flex: 1 }}
        />
        <span style={{ fontSize: 12, color: "var(--color-text-secondary)", minWidth: 80 }}>{question.high}</span>
        <span style={{ fontSize: 14, fontWeight: 500, minWidth: 24, textAlign: "center", color: "var(--color-text-info)" }}>{value}</span>
      </div>
    </div>
  );
}

export default function FinancialStrategy() {
  const [phase, setPhase] = useState(0);
  const [valuesRanked, setValuesRanked] = useState([]);
  const [currency, setCurrency] = useState("£");
  const [income, setIncome] = useState({});
  const [expenses, setExpenses] = useState({});
  const [assets, setAssets] = useState({});
  const [debts, setDebts] = useState({});
  const [debtRates, setDebtRates] = useState({});
  const [goals, setGoals] = useState([
    { id: 1, name: "", amount: "", timeframe: "1-2 years", priority: "high" },
  ]);
  const [behavior, setBehavior] = useState(
    Object.fromEntries(BEHAVIOR_QUESTIONS.map((q) => [q.id, 5]))
  );
  const [completedPhases, setCompletedPhases] = useState(new Set());

  const currentPhase = PHASES[phase];

  function markComplete() {
    setCompletedPhases(new Set([...completedPhases, currentPhase.id]));
  }

  function goNext() {
    markComplete();
    setPhase(Math.min(phase + 1, PHASES.length - 1));
  }

  function goPrev() {
    setPhase(Math.max(phase - 1, 0));
  }

  const totalIncome = INCOME_CATEGORIES.reduce((s, c) => s + parseNum(income[c.id]), 0);
  const totalExpenses = EXPENSE_CATEGORIES.reduce((s, c) => s + parseNum(expenses[c.id]), 0);
  const totalAssets = ASSET_TYPES.reduce((s, c) => s + parseNum(assets[c.id]), 0);
  const totalDebts = DEBT_TYPES.reduce((s, c) => s + parseNum(debts[c.id]), 0);
  const netWorth = totalAssets - totalDebts;
  const monthlySurplus = totalIncome - totalExpenses;

  function addGoal() {
    setGoals([...goals, { id: Date.now(), name: "", amount: "", timeframe: "1-2 years", priority: "medium" }]);
  }

  function updateGoal(id, field, val) {
    setGoals(goals.map((g) => (g.id === id ? { ...g, [field]: val } : g)));
  }

  function removeGoal(id) {
    if (goals.length <= 1) return;
    setGoals(goals.filter((g) => g.id !== id));
  }

  function generatePrompt() {
    const sections = [];

    if (valuesRanked.length > 0) {
      const vals = valuesRanked.map((id, i) => {
        const v = VALUES_LIST.find((x) => x.id === id);
        return `${i + 1}. ${v.label}`;
      }).join(", ");
      sections.push(`My financial values in priority order: ${vals}`);
    }

    if (totalIncome > 0 || totalExpenses > 0) {
      const incLines = INCOME_CATEGORIES.filter((c) => parseNum(income[c.id]) > 0)
        .map((c) => `${c.label}: ${currency}${fmt(parseNum(income[c.id]))}/mo`).join(", ");
      const expLines = EXPENSE_CATEGORIES.filter((c) => parseNum(expenses[c.id]) > 0)
        .map((c) => `${c.label}: ${currency}${fmt(parseNum(expenses[c.id]))}/mo`).join(", ");
      sections.push(`Monthly income (${currency}${fmt(totalIncome)} total): ${incLines || "none entered"}`);
      sections.push(`Monthly expenses (${currency}${fmt(totalExpenses)} total): ${expLines || "none entered"}`);
      sections.push(`Monthly surplus: ${currency}${fmt(monthlySurplus)}`);
    }

    if (totalAssets > 0 || totalDebts > 0) {
      const aLines = ASSET_TYPES.filter((c) => parseNum(assets[c.id]) > 0)
        .map((c) => `${c.label}: ${currency}${fmt(parseNum(assets[c.id]))}`).join(", ");
      const dLines = DEBT_TYPES.filter((c) => parseNum(debts[c.id]) > 0)
        .map((c) => {
          const rate = debtRates[c.id] ? ` at ${debtRates[c.id]}%` : "";
          return `${c.label}: ${currency}${fmt(parseNum(debts[c.id]))}${rate}`;
        }).join(", ");
      sections.push(`Assets (${currency}${fmt(totalAssets)} total): ${aLines || "none"}`);
      sections.push(`Debts (${currency}${fmt(totalDebts)} total): ${dLines || "none"}`);
      sections.push(`Net worth: ${currency}${fmt(netWorth)}`);
    }

    const validGoals = goals.filter((g) => g.name.trim());
    if (validGoals.length > 0) {
      const gLines = validGoals.map((g) =>
        `${g.name} — target ${currency}${g.amount || "?"} in ${g.timeframe} (${g.priority} priority)`
      ).join("; ");
      sections.push(`Financial goals: ${gLines}`);
    }

    const bLines = BEHAVIOR_QUESTIONS.map((q) => `${q.label}: ${behavior[q.id]}/10`).join("; ");
    sections.push(`Behavioral profile: ${bLines}`);

    return `Here is my complete financial profile. Based on all of this data, please give me a comprehensive financial analysis and personalised action plan. Identify my biggest opportunities and risks, suggest specific optimisations for my spending, and help me build a realistic roadmap toward my goals.\n\n${sections.join("\n\n")}`;
  }

  const phaseContent = {
    overview: (
      <div>
        <div style={{ fontSize: 22, fontWeight: 500, marginBottom: 8 }}>Financial data collection strategy</div>
        <p style={{ fontSize: 14, color: "var(--color-text-secondary)", lineHeight: 1.7, marginBottom: "1.5rem" }}>
          This tool collects everything I need to give you genuinely useful financial advice — not generic tips.
          Each phase uses a different technique designed for the type of information being gathered.
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {PHASES.slice(1, -1).map((p, i) => (
            <div
              key={p.id}
              style={{
                display: "flex", gap: 14, padding: "14px 16px",
                background: "var(--color-background-primary)",
                border: "0.5px solid var(--color-border-tertiary)",
                borderRadius: "var(--border-radius-lg)",
                cursor: "pointer",
                transition: "all 0.15s",
              }}
              onClick={() => setPhase(i + 1)}
            >
              <div style={{
                width: 36, height: 36, borderRadius: "var(--border-radius-md)",
                background: completedPhases.has(p.id) ? "var(--color-background-success)" : "var(--color-background-secondary)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 16, flexShrink: 0,
                color: completedPhases.has(p.id) ? "var(--color-text-success)" : "var(--color-text-secondary)",
              }}>
                {completedPhases.has(p.id) ? "✓" : p.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 2 }}>
                  <span style={{ fontSize: 14, fontWeight: 500 }}>Phase {i + 1}: {p.label}</span>
                  <span style={{
                    fontSize: 11, padding: "2px 8px",
                    background: "var(--color-background-info)",
                    color: "var(--color-text-info)",
                    borderRadius: "var(--border-radius-md)",
                  }}>{p.technique}</span>
                </div>
                <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.5 }}>{p.description}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),

    values: (
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1.5rem" }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 4 }}>What matters most to you?</div>
            <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6 }}>
              Rank these in order of importance. Your top 3-4 will heavily shape my recommendations.
            </div>
          </div>
        </div>
        <DragRanker items={VALUES_LIST} ranked={valuesRanked} setRanked={setValuesRanked} />
      </div>
    ),

    cashflow: (
      <div>
        <div style={{ marginBottom: "1.5rem" }}>
          <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 4 }}>Monthly cash flow</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6, marginBottom: 12 }}>
            Enter your average monthly figures. Estimates are fine — we can refine later.
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
            <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>Currency:</span>
            {["£", "$", "€"].map((c) => (
              <button
                key={c}
                onClick={() => setCurrency(c)}
                style={{
                  padding: "4px 12px", fontSize: 14, fontWeight: 500,
                  background: currency === c ? "var(--color-background-info)" : "transparent",
                  color: currency === c ? "var(--color-text-info)" : "var(--color-text-secondary)",
                  border: "0.5px solid var(--color-border-tertiary)",
                  borderRadius: "var(--border-radius-md)", cursor: "pointer",
                }}
              >{c}</button>
            ))}
          </div>
        </div>
        <div style={{ marginBottom: "1.5rem" }}>
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 10, color: "var(--color-text-success)" }}>Income</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {INCOME_CATEGORIES.map((c) => (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 13, color: "var(--color-text-secondary)", minWidth: 160 }}>{c.label}</span>
                <div style={{ flex: 1 }}>
                  <NumberInput
                    value={income[c.id] || ""}
                    onChange={(v) => setIncome({ ...income, [c.id]: v })}
                    placeholder={c.placeholder}
                    prefix={currency}
                    suffix="/mo"
                  />
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 10, fontSize: 14, fontWeight: 500, textAlign: "right", color: "var(--color-text-success)" }}>
            Total: {currency}{fmt(totalIncome)}/mo
          </div>
        </div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 10, color: "var(--color-text-danger)" }}>Expenses</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {EXPENSE_CATEGORIES.map((c) => (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 13, color: "var(--color-text-secondary)", minWidth: 160 }}>{c.label}</span>
                <div style={{ flex: 1 }}>
                  <NumberInput
                    value={expenses[c.id] || ""}
                    onChange={(v) => setExpenses({ ...expenses, [c.id]: v })}
                    placeholder={c.placeholder}
                    prefix={currency}
                    suffix="/mo"
                  />
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 10, fontSize: 14, fontWeight: 500, textAlign: "right", color: "var(--color-text-danger)" }}>
            Total: {currency}{fmt(totalExpenses)}/mo
          </div>
        </div>
        <div style={{
          marginTop: "1.5rem", padding: "14px 16px",
          background: monthlySurplus >= 0 ? "var(--color-background-success)" : "var(--color-background-danger)",
          borderRadius: "var(--border-radius-md)", textAlign: "center",
        }}>
          <div style={{ fontSize: 12, color: monthlySurplus >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)", marginBottom: 2 }}>Monthly surplus</div>
          <div style={{
            fontSize: 22, fontWeight: 500,
            color: monthlySurplus >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)",
          }}>{currency}{fmt(monthlySurplus)}</div>
        </div>
      </div>
    ),

    assets: (
      <div>
        <div style={{ marginBottom: "1.5rem" }}>
          <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 4 }}>Balance sheet</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6 }}>
            Current balances — approximate values are perfectly fine at this stage.
          </div>
        </div>
        <div style={{ marginBottom: "1.5rem" }}>
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 10, color: "var(--color-text-success)" }}>Assets — what you own</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {ASSET_TYPES.map((c) => (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 13, color: "var(--color-text-secondary)", minWidth: 140 }}>{c.label}</span>
                <div style={{ flex: 1 }}>
                  <NumberInput
                    value={assets[c.id] || ""}
                    onChange={(v) => setAssets({ ...assets, [c.id]: v })}
                    placeholder={c.placeholder}
                    prefix={currency}
                  />
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 10, fontSize: 14, fontWeight: 500, textAlign: "right", color: "var(--color-text-success)" }}>
            Total assets: {currency}{fmt(totalAssets)}
          </div>
        </div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 10, color: "var(--color-text-danger)" }}>Debts — what you owe</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {DEBT_TYPES.map((c) => (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 13, color: "var(--color-text-secondary)", minWidth: 120 }}>{c.label}</span>
                <div style={{ flex: 1 }}>
                  <NumberInput
                    value={debts[c.id] || ""}
                    onChange={(v) => setDebts({ ...debts, [c.id]: v })}
                    placeholder={c.placeholder}
                    prefix={currency}
                  />
                </div>
                <div style={{ width: 90 }}>
                  <NumberInput
                    value={debtRates[c.id] || ""}
                    onChange={(v) => setDebtRates({ ...debtRates, [c.id]: v })}
                    placeholder={c.ratePlaceholder}
                    prefix=""
                    suffix="% APR"
                  />
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 10, fontSize: 14, fontWeight: 500, textAlign: "right", color: "var(--color-text-danger)" }}>
            Total debts: {currency}{fmt(totalDebts)}
          </div>
        </div>
        <div style={{
          marginTop: "1.5rem", padding: "14px 16px",
          background: netWorth >= 0 ? "var(--color-background-success)" : "var(--color-background-danger)",
          borderRadius: "var(--border-radius-md)", textAlign: "center",
        }}>
          <div style={{ fontSize: 12, color: netWorth >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)", marginBottom: 2 }}>Net worth</div>
          <div style={{
            fontSize: 22, fontWeight: 500,
            color: netWorth >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)",
          }}>{currency}{fmt(netWorth)}</div>
        </div>
      </div>
    ),

    goals: (
      <div>
        <div style={{ marginBottom: "1.5rem" }}>
          <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 4 }}>Financial goals</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6 }}>
            What are you working toward? Be as specific as possible — "save for a house deposit" beats "save money."
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {goals.map((g, i) => (
            <div
              key={g.id}
              style={{
                padding: "14px 16px",
                background: "var(--color-background-primary)",
                border: "0.5px solid var(--color-border-tertiary)",
                borderRadius: "var(--border-radius-lg)",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <span style={{ fontSize: 13, fontWeight: 500, color: "var(--color-text-secondary)" }}>Goal {i + 1}</span>
                {goals.length > 1 && (
                  <button onClick={() => removeGoal(g.id)} style={{
                    fontSize: 12, padding: "2px 8px", background: "transparent",
                    border: "0.5px solid var(--color-border-tertiary)", borderRadius: 4,
                    cursor: "pointer", color: "var(--color-text-danger)",
                  }}>Remove</button>
                )}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <input
                  type="text"
                  placeholder="e.g. House deposit, emergency fund, holiday..."
                  value={g.name}
                  onChange={(e) => updateGoal(g.id, "name", e.target.value)}
                  style={{ fontSize: 14 }}
                />
                <div style={{ display: "flex", gap: 8 }}>
                  <div style={{ flex: 1 }}>
                    <NumberInput
                      value={g.amount}
                      onChange={(v) => updateGoal(g.id, "amount", v)}
                      placeholder="Target amount"
                      prefix={currency}
                    />
                  </div>
                  <select
                    value={g.timeframe}
                    onChange={(e) => updateGoal(g.id, "timeframe", e.target.value)}
                    style={{ fontSize: 13, padding: "6px 10px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-tertiary)", background: "var(--color-background-primary)", color: "var(--color-text-primary)" }}
                  >
                    <option value="< 6 months">Under 6 months</option>
                    <option value="6-12 months">6-12 months</option>
                    <option value="1-2 years">1-2 years</option>
                    <option value="2-5 years">2-5 years</option>
                    <option value="5-10 years">5-10 years</option>
                    <option value="10+ years">10+ years</option>
                  </select>
                  <select
                    value={g.priority}
                    onChange={(e) => updateGoal(g.id, "priority", e.target.value)}
                    style={{ fontSize: 13, padding: "6px 10px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-tertiary)", background: "var(--color-background-primary)", color: "var(--color-text-primary)" }}
                  >
                    <option value="high">High priority</option>
                    <option value="medium">Medium</option>
                    <option value="low">Nice to have</option>
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
        <button
          onClick={addGoal}
          style={{
            marginTop: 12, width: "100%", padding: "10px",
            background: "transparent",
            border: "1px dashed var(--color-border-secondary)",
            borderRadius: "var(--border-radius-md)",
            cursor: "pointer", fontSize: 13,
            color: "var(--color-text-secondary)",
          }}
        >+ Add another goal</button>
      </div>
    ),

    behavior: (
      <div>
        <div style={{ marginBottom: "1.5rem" }}>
          <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 4 }}>Your money personality</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6 }}>
            Be honest — there's no right answer. This helps me tailor advice to how you actually behave, not how you wish you did.
          </div>
        </div>
        {BEHAVIOR_QUESTIONS.map((q) => (
          <SliderQuestion
            key={q.id}
            question={q}
            value={behavior[q.id]}
            onChange={(v) => setBehavior({ ...behavior, [q.id]: v })}
          />
        ))}
      </div>
    ),

    summary: (
      <div>
        <div style={{ fontSize: 18, fontWeight: 500, marginBottom: 4 }}>Your financial data brief</div>
        <p style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6, marginBottom: "1.5rem" }}>
          Here's a summary of everything you've entered. When you're ready, send it to me and I'll build your personalised financial plan.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: "1.5rem" }}>
          {[
            { label: "Monthly income", value: `${currency}${fmt(totalIncome)}`, color: "success" },
            { label: "Monthly expenses", value: `${currency}${fmt(totalExpenses)}`, color: "danger" },
            { label: "Monthly surplus", value: `${currency}${fmt(monthlySurplus)}`, color: monthlySurplus >= 0 ? "success" : "danger" },
            { label: "Net worth", value: `${currency}${fmt(netWorth)}`, color: netWorth >= 0 ? "success" : "danger" },
          ].map((s) => (
            <div key={s.label} style={{
              padding: "12px 14px",
              background: "var(--color-background-secondary)",
              borderRadius: "var(--border-radius-md)",
            }}>
              <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 2 }}>{s.label}</div>
              <div style={{ fontSize: 18, fontWeight: 500, color: `var(--color-text-${s.color})` }}>{s.value}</div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: "1.5rem" }}>
          {[
            { label: "Values ranked", status: valuesRanked.length > 0, detail: valuesRanked.length > 0 ? `${valuesRanked.length} values ranked` : "Not completed" },
            { label: "Cash flow mapped", status: totalIncome > 0 || totalExpenses > 0, detail: totalIncome > 0 ? "Entered" : "Not completed" },
            { label: "Balance sheet", status: totalAssets > 0 || totalDebts > 0, detail: totalAssets > 0 ? "Entered" : "Not completed" },
            { label: "Goals defined", status: goals.some((g) => g.name.trim()), detail: goals.filter((g) => g.name.trim()).length + " goals" },
            { label: "Behavior profile", status: true, detail: "Completed" },
          ].map((item) => (
            <div key={item.label} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13 }}>
              <span style={{
                width: 20, height: 20, borderRadius: "50%",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 11,
                background: item.status ? "var(--color-background-success)" : "var(--color-background-secondary)",
                color: item.status ? "var(--color-text-success)" : "var(--color-text-secondary)",
              }}>{item.status ? "✓" : "—"}</span>
              <span style={{ fontWeight: 500 }}>{item.label}</span>
              <span style={{ color: "var(--color-text-secondary)" }}>{item.detail}</span>
            </div>
          ))}
        </div>
        <button
          onClick={() => {
            const prompt = generatePrompt();
            if (window.sendPrompt) window.sendPrompt(prompt);
          }}
          style={{
            width: "100%", padding: "14px",
            background: "var(--color-text-primary)",
            color: "var(--color-background-primary)",
            border: "none",
            borderRadius: "var(--border-radius-md)",
            cursor: "pointer", fontSize: 14, fontWeight: 500,
            transition: "opacity 0.15s",
          }}
          onMouseEnter={(e) => e.target.style.opacity = "0.85"}
          onMouseLeave={(e) => e.target.style.opacity = "1"}
        >
          Send my financial profile to Claude for analysis ↗
        </button>
      </div>
    ),
  };

  return (
    <div style={{ maxWidth: 680, margin: "0 auto", padding: "0.5rem 0" }}>
      <div style={{
        display: "flex", gap: 4, marginBottom: "1.5rem", overflowX: "auto",
        padding: "2px 0",
      }}>
        {PHASES.map((p, i) => (
          <button
            key={p.id}
            onClick={() => setPhase(i)}
            style={{
              padding: "6px 12px",
              fontSize: 12,
              fontWeight: phase === i ? 500 : 400,
              background: phase === i ? "var(--color-text-primary)" : "transparent",
              color: phase === i ? "var(--color-background-primary)" : completedPhases.has(p.id) ? "var(--color-text-success)" : "var(--color-text-secondary)",
              border: phase === i ? "none" : "0.5px solid var(--color-border-tertiary)",
              borderRadius: "var(--border-radius-md)",
              cursor: "pointer",
              whiteSpace: "nowrap",
              transition: "all 0.15s",
            }}
          >
            {completedPhases.has(p.id) && phase !== i ? "✓ " : ""}{p.label}
          </button>
        ))}
      </div>

      {currentPhase.technique && (
        <div style={{
          display: "flex", justifyContent: "space-between", alignItems: "center",
          marginBottom: "1rem", padding: "8px 12px",
          background: "var(--color-background-secondary)",
          borderRadius: "var(--border-radius-md)",
        }}>
          <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>
            Technique: {currentPhase.technique}
          </span>
          <span style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>
            {currentPhase.why}
          </span>
        </div>
      )}

      <div style={{
        background: "var(--color-background-primary)",
        border: "0.5px solid var(--color-border-tertiary)",
        borderRadius: "var(--border-radius-lg)",
        padding: "1.25rem",
      }}>
        {phaseContent[currentPhase.id]}
      </div>

      {phase > 0 && phase < PHASES.length - 1 && (
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: "1rem" }}>
          <button
            onClick={goPrev}
            style={{
              padding: "8px 20px", fontSize: 13, background: "transparent",
              border: "0.5px solid var(--color-border-tertiary)",
              borderRadius: "var(--border-radius-md)", cursor: "pointer",
              color: "var(--color-text-secondary)",
            }}
          >← Previous</button>
          <button
            onClick={goNext}
            style={{
              padding: "8px 20px", fontSize: 13,
              background: "var(--color-text-primary)",
              color: "var(--color-background-primary)",
              border: "none",
              borderRadius: "var(--border-radius-md)", cursor: "pointer", fontWeight: 500,
            }}
          >Save & continue →</button>
        </div>
      )}
      {phase === PHASES.length - 1 && (
        <div style={{ display: "flex", justifyContent: "flex-start", marginTop: "1rem" }}>
          <button
            onClick={goPrev}
            style={{
              padding: "8px 20px", fontSize: 13, background: "transparent",
              border: "0.5px solid var(--color-border-tertiary)",
              borderRadius: "var(--border-radius-md)", cursor: "pointer",
              color: "var(--color-text-secondary)",
            }}
          >← Back to edit</button>
        </div>
      )}
    </div>
  );
}
