# Implementation Plan: Trust-First Personal Finance Advisor

## Vision

A hybrid chat + dashboard personal finance app that builds a psychological and financial portrait of each user through progressive conversation, delivering increasingly personalised advice powered by Claude — with structured data, system-computed analytics, and proactive nudges supporting the LLM where it can't be trusted alone.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────┐
│                  Vercel (Frontend)               │
│  Next.js App Router + Vercel AI SDK (useChat)    │
│  Dashboard views + Chat interface                │
│  CSV upload + Progressive onboarding UI          │
└─────────────┬───────────────────────┬────────────┘
              │                       │
              ▼                       ▼
┌─────────────────────┐  ┌─────────────────────────┐
│   Claude API        │  │   Supabase              │
│   (Intelligence)    │  │   Auth / DB / Storage   │
│                     │  │   Edge Functions        │
│   - Chat responses  │  │   - Scheduled jobs      │
│   - Analysis        │  │   - Transaction parser  │
│   - Advice          │  │   - Analytics engine    │
│   - Profile writes  │  │   - Nudge system        │
└─────────────────────┘  └─────────────────────────┘
```

**Key principle: The LLM interprets. The system computes.**

Claude never does arithmetic, date calculations, or budget tracking. Supabase Edge Functions compute all financial metrics and inject them as structured context into Claude's system prompt. Claude's job is to understand the user, explain the numbers, and give personalised advice.

---

## Tech Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| Framework | Next.js 14+ App Router | Lewis's primary stack, SSR, API routes |
| Hosting | Vercel | Seamless Next.js deployment, edge functions |
| Auth | Supabase Auth (email + Google) | Multi-tenant from day one, RLS |
| Database | Supabase PostgreSQL | Structured financial data, RLS policies |
| Storage | Supabase Storage | CSV uploads, document storage |
| Chat | Vercel AI SDK (`useChat`) + Claude API | Streaming, conversation management |
| LLM | Claude Sonnet (chat) / Opus (deep analysis) | Cost-effective for chat, powerful for analysis |
| Cron/Background | Supabase Edge Functions + pg_cron | Scheduled analytics, nudges |
| Styling | Tailwind CSS | Fast, utility-first |
| State | React state + SWR/React Query | Server state management |

---

## Design Principles → Technical Decisions

### 1. "Ask late, ask little"
- **Technical:** No registration form with 10 fields. Email + password only. Everything else gathered through conversation or inferred from uploaded data.
- **Schema:** `user_profiles` table has mostly nullable columns. Fields populate over time.
- **Chat:** The system tracks which profile fields are empty and prompts for them only when contextually relevant (e.g., don't ask about kids until they mention family).

### 2. "Deliver value before depth"
- **Technical:** The first "aha moment" happens within 5 minutes: upload a CSV → see your real spending breakdown → get one actionable insight.
- **Implementation:** The CSV parser + auto-categorizer runs instantly. The first dashboard render shows spending by category before the user has answered a single question.
- **Chat:** First message after CSV upload is Claude presenting the key finding (like the deficit we discovered), not asking more questions.

### 3. "Be explicit about why data is needed"
- **Technical:** Every data collection touchpoint shows a `why_needed` tooltip/explanation.
- **Chat:** When Claude asks a question, the system injects a brief explanation of what the answer unlocks. "I'm asking because this determines whether I recommend saving or investing first."
- **Schema:** `profile_questions` table includes a `rationale` field shown to users.

### 4. "Don't rely on the LLM alone"
- **Technical:** Financial calculations happen in SQL/Edge Functions and are injected as structured context.
- **Categories:** Transaction categorization uses a rules engine first, LLM second (for uncategorized).
- **Validation:** When Claude writes to the profile (via function calling), the system validates before saving.
- **Guardrails:** Budget alerts, balance tracking, and bill comparisons are system-computed.

### 5. "Make every interaction trust-building"
- **Technical:** Every chat message shows what Claude knows (context indicator). The user can always see and correct their profile. Progress indicators show how complete their financial portrait is.
- **UI:** A "What Claude knows about me" panel accessible from any screen. An accuracy score that improves with corrections.

---

## Database Schema (Supabase)

### Core Tables

```sql
-- Users and profiles (progressive, mostly nullable)
create table user_profiles (
  id uuid primary key references auth.users(id),
  display_name text,
  
  -- Location & basics (gathered early)
  country text,
  city text,
  primary_currency text default 'EUR',
  age_range text, -- '26-30', '31-35', etc.
  
  -- Employment (gathered when discussing income)
  employment_status text, -- 'employed', 'freelance', 'unemployed'
  gross_salary numeric,
  net_monthly_income numeric,
  pay_frequency text, -- 'monthly', 'biweekly'
  has_bonus_months boolean,
  bonus_month_details jsonb, -- [{month: 3, amount: 6700}, {month: 6, amount: 5400}]
  
  -- Housing (gathered when discussing expenses)
  housing_type text, -- 'renting', 'mortgage', 'owned', 'shared'
  monthly_rent numeric,
  
  -- Household (gathered naturally)
  relationship_status text,
  partner_employment_status text,
  partner_monthly_contribution numeric,
  dependents integer default 0,
  
  -- Financial psychology (built over time through conversation)
  values_ranking jsonb, -- ordered array of value IDs
  spending_triggers jsonb, -- ['money_available', 'social_pressure', 'stress']
  risk_tolerance text, -- 'low', 'medium', 'high'
  financial_awareness text, -- 'low', 'medium', 'high'
  advice_style text, -- 'gentle', 'direct', 'blunt'
  
  -- Residency & tax (gathered when relevant)
  nationality text,
  residency_status text,
  tax_residency_country text,
  years_in_country integer,
  
  -- Metadata
  onboarding_completed_at timestamptz,
  profile_completeness integer default 0, -- 0-100
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Accounts the user has
create table accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  name text not null, -- 'Revolut', 'Santander Current', etc.
  type text not null, -- 'spending', 'current', 'savings', 'credit_card', 'investment', 'crypto', 'pension'
  provider text, -- 'Revolut', 'Santander', 'Hargreaves Lansdown'
  currency text default 'EUR',
  current_balance numeric,
  is_primary_spending boolean default false,
  metadata jsonb, -- flexible: plan type, interest rate, etc.
  created_at timestamptz default now()
);

-- Transactions (from CSV imports or bank API)
create table transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  account_id uuid references accounts(id),
  
  -- Core fields
  date timestamptz not null,
  description text not null,
  amount numeric not null, -- negative for outflows
  currency text default 'EUR',
  
  -- Categorization
  category_id uuid references categories(id),
  auto_category_confidence numeric, -- 0-1, how sure the system is
  user_confirmed boolean default false,
  
  -- Context
  is_recurring boolean default false,
  is_shared_expense boolean default false, -- e.g., paid for friends, will be reimbursed
  is_holiday_spend boolean default false,
  tags text[],
  notes text,
  
  -- Import metadata
  source text, -- 'csv_revolut', 'csv_santander', 'bank_api', 'manual'
  import_batch_id uuid,
  raw_description text, -- original before cleanup
  
  created_at timestamptz default now()
);

-- Spending categories with smart defaults
create table categories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  name text not null,
  icon text,
  color text,
  monthly_budget numeric,
  is_fixed boolean default false, -- rent, utilities vs discretionary
  is_essential boolean default true,
  sort_order integer,
  
  -- Matching rules for auto-categorization
  matching_rules jsonb -- [{pattern: 'aldi|mercadona|caprabo', type: 'contains'}]
);

-- Recurring bills/expenses
create table recurring_expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  account_id uuid references accounts(id),
  category_id uuid references categories(id),
  
  name text not null, -- 'Iberdrola Electricity'
  provider text,
  amount numeric not null,
  currency text default 'EUR',
  frequency text not null, -- 'monthly', 'bimonthly', 'quarterly', 'annual'
  billing_day integer, -- day of month
  
  -- Optimization data
  current_plan_details jsonb, -- {speed: '750Mb', data: '100GB', rate_kwh: 0.2235}
  contract_end_date date,
  has_permanencia boolean default false,
  last_optimisation_check timestamptz,
  potential_saving_monthly numeric,
  switch_recommendation text,
  
  created_at timestamptz default now()
);

-- Financial goals
create table goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  
  name text not null,
  description text,
  target_amount numeric,
  current_amount numeric default 0,
  target_date date,
  priority text, -- 'high', 'medium', 'low'
  status text default 'active', -- 'active', 'paused', 'achieved', 'abandoned'
  
  -- Progress tracking
  monthly_required_saving numeric, -- computed
  on_track boolean, -- computed
  
  created_at timestamptz default now()
);

-- Investment holdings
create table investment_holdings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  account_id uuid references accounts(id),
  
  ticker text,
  name text not null,
  asset_type text, -- 'stock', 'etf', 'investment_trust', 'gilt', 'crypto', 'cash'
  quantity numeric,
  current_value numeric,
  cost_basis numeric,
  currency text default 'GBP',
  gain_loss_pct numeric,
  allocation_pct numeric, -- computed
  
  last_updated timestamptz default now()
);

-- Chat conversations and messages
create table conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  title text,
  type text default 'general', -- 'onboarding', 'monthly_review', 'trip_planning', 'scenario', 'general'
  status text default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references conversations(id) on delete cascade,
  role text not null, -- 'user', 'assistant', 'system'
  content text not null,
  
  -- Structured data extracted from this message
  profile_updates jsonb, -- fields that were updated from this message
  actions_created jsonb, -- action items generated
  insights_generated jsonb, -- insights surfaced
  
  -- Tool use tracking
  tools_used text[], -- ['web_search', 'calculate_budget', 'categorize_transactions']
  
  created_at timestamptz default now()
);

-- Action items / recommendations
create table action_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  conversation_id uuid references conversations(id),
  
  title text not null,
  description text,
  category text, -- 'bill_switch', 'savings_transfer', 'investment', 'admin', 'research'
  priority text, -- 'high', 'medium', 'low'
  status text default 'pending', -- 'pending', 'in_progress', 'completed', 'dismissed'
  due_date date,
  
  -- For nudge system
  last_nudge_at timestamptz,
  nudge_count integer default 0,
  
  completed_at timestamptz,
  created_at timestamptz default now()
);

-- Monthly snapshots (system-computed)
create table monthly_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  month date not null, -- first day of month
  
  total_income numeric,
  total_fixed_costs numeric,
  total_discretionary numeric,
  total_spending numeric,
  surplus_deficit numeric,
  
  -- Category breakdown
  spending_by_category jsonb, -- {groceries: 274, dining: 416, ...}
  
  -- Behavioral metrics
  transaction_count integer,
  dining_out_count integer,
  avg_transaction_size numeric,
  largest_transaction numeric,
  largest_transaction_desc text,
  
  -- Comparison
  vs_previous_month_pct numeric,
  vs_budget_pct numeric,
  
  created_at timestamptz default now(),
  unique(user_id, month)
);

-- Financial portrait (LLM-generated insights, system-validated)
create table financial_portrait (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  
  trait_type text not null, -- 'behavioral', 'pattern', 'preference', 'insight'
  trait_key text not null, -- 'spending_trigger', 'dining_pattern', 'holiday_impact'
  trait_value text not null, -- 'Spends when money is visible in account'
  confidence numeric default 0.5, -- 0-1
  evidence text, -- 'Based on 6 months of data showing...'
  source_conversation_id uuid references conversations(id),
  
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique(user_id, trait_key)
);

-- Nudges and notifications
create table nudges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  
  type text not null, -- 'payday_transfer', 'bill_due', 'budget_alert', 'monthly_review', 'action_reminder'
  title text not null,
  body text not null,
  action_url text, -- deep link into the app
  
  trigger_rule jsonb, -- {type: 'payday', days_before: 0}
  
  status text default 'pending', -- 'pending', 'sent', 'read', 'actioned', 'dismissed'
  scheduled_for timestamptz,
  sent_at timestamptz,
  read_at timestamptz,
  
  created_at timestamptz default now()
);
```

### Row Level Security

```sql
-- Every table gets RLS: users can only see their own data
alter table user_profiles enable row level security;
create policy "Users can view own profile" on user_profiles
  for select using (auth.uid() = id);
create policy "Users can update own profile" on user_profiles
  for update using (auth.uid() = id);

-- Same pattern for all user-scoped tables
-- account_id and conversation_id lookups go through user_id
```

---

## Session-Based Implementation Plan

### Session 1: Project Foundation (Day 1-2)
**Goal:** Deployable shell with auth, database, and basic navigation.

```
Tasks:
├── Create Next.js project with App Router
├── Configure Supabase project
│   ├── Run schema migration (core tables above)
│   ├── Enable RLS on all tables
│   └── Configure auth (email + Google OAuth)
├── Set up Vercel deployment
│   ├── Environment variables (Supabase, Claude API key)
│   └── Automatic preview deploys from Git
├── Build layout shell
│   ├── Auth pages (sign up, sign in)
│   ├── Authenticated layout with sidebar
│   ├── Three main routes: /chat, /dashboard, /profile
│   └── Mobile-responsive navigation
├── Seed default categories for new users
│   └── Supabase trigger on user creation → insert default categories
└── Verify: Can sign up, sign in, see empty dashboard, navigate between routes
```

**Design principle applied:** The signup is email + password only. No other questions. The first screen after signup guides them to either start chatting or upload a CSV.

---

### Session 2: Chat Foundation (Day 2-3)
**Goal:** Working chat interface connected to Claude API with basic conversation persistence.

```
Tasks:
├── Install and configure Vercel AI SDK
│   ├── Set up /api/chat route handler
│   ├── Configure Claude as the model provider
│   └── Implement streaming responses
├── Build chat UI
│   ├── Message list with user/assistant styling
│   ├── Input field with send button
│   ├── Streaming response indicator
│   ├── Conversation history sidebar
│   └── Mobile-optimised layout
├── Conversation persistence
│   ├── Create conversation on first message
│   ├── Save messages to Supabase after each exchange
│   └── Load conversation history on page load
├── System prompt engineering
│   ├── Base system prompt with financial advisor persona
│   ├── Context injection point for user profile data
│   ├── Context injection point for computed financial metrics
│   └── Instruction for when/how to ask for data
└── Verify: Can have a multi-turn conversation, messages persist across page loads
```

**System prompt structure:**
```
[Base persona and rules]
[User profile: {injected from user_profiles}]
[Financial summary: {injected from monthly_snapshots}]
[Active goals: {injected from goals}]
[Recent action items: {injected from action_items}]
[Financial portrait traits: {injected from financial_portrait}]
[Available tools: {function definitions}]
[Current conversation context]
```

---

### Session 3: CSV Upload & Transaction Engine (Day 3-5)
**Goal:** Upload a Revolut or Santander CSV, auto-parse, auto-categorize, and show the spending breakdown.

```
Tasks:
├── CSV upload UI
│   ├── Drag-and-drop zone
│   ├── Format auto-detection (Revolut vs Santander vs generic)
│   ├── Upload progress indicator
│   └── Preview of parsed transactions before confirming
├── CSV parser (Edge Function)
│   ├── Revolut CSV parser (Type, Date, Description, Amount, Fee, Balance)
│   ├── Santander XLSX parser (Spanish format, comma decimals)
│   ├── Generic CSV parser with column mapping UI
│   ├── Duplicate detection (same date + amount + description)
│   └── Currency detection and normalisation
├── Auto-categorization engine
│   ├── Rules-based first pass (pattern matching on description)
│   │   ├── Default rules: Aldi|Mercadona|Caprabo → Groceries
│   │   ├── User-defined rules (learned from corrections)
│   │   └── Confidence scoring (exact match = 1.0, fuzzy = 0.6)
│   ├── LLM second pass (for unmatched transactions)
│   │   ├── Batch uncategorized transactions
│   │   ├── Send to Claude with category options
│   │   └── Save with lower confidence score
│   └── User correction flow
│       ├── Click to recategorize any transaction
│       ├── "Apply to all similar" option
│       └── Corrections feed back into rules engine
├── Post-import analytics (Edge Function)
│   ├── Compute monthly_snapshots for imported months
│   ├── Detect recurring transactions
│   ├── Flag potential shared/reimbursed expenses
│   └── Identify holiday spending clusters (foreign merchants)
└── Verify: Upload Revolut CSV → see categorized transactions → spending breakdown renders
```

**Design principle applied:** "Deliver value before depth." The moment CSV is uploaded, the user sees their spending breakdown. No questions required. The "aha moment" happens before any conversation.

---

### Session 4: The Aha Moment — First Analysis (Day 5-6)
**Goal:** After CSV upload, automatically generate the user's first financial insight through chat.

```
Tasks:
├── Post-upload chat trigger
│   ├── After CSV processing completes, auto-start a conversation
│   ├── System injects the computed spending breakdown as context
│   └── Claude presents the key finding (biggest category, trends, surprises)
├── Structured insight extraction
│   ├── Claude's analysis response is parsed for key insights
│   ├── Insights saved to financial_portrait table
│   └── Action items extracted and saved to action_items table
├── Interactive follow-up flow
│   ├── Claude asks 2-3 targeted follow-up questions based on what the data shows
│   ├── Questions use the ask_user_input pattern (tappable options, not open text)
│   ├── Answers update user_profiles and financial_portrait
│   └── Each answer triggers a refined insight
├── Profile completeness tracking
│   ├── Calculate completeness % based on filled fields
│   ├── Show progress indicator in sidebar
│   └── Never pressure — just show what's known vs unknown
└── Verify: Upload CSV → Claude presents spending analysis → user answers 2-3 questions → profile partially populated → dashboard shows initial data
```

**This is the critical flow.** If this session works well, the user goes from "stranger" to "I'm impressed" in under 5 minutes.

---

### Session 5: Dashboard — Financial Overview (Day 6-8)
**Goal:** A clean dashboard showing the user's real financial picture at a glance.

```
Tasks:
├── Dashboard layout
│   ├── Monthly summary cards (income, expenses, surplus/deficit)
│   ├── Month selector (navigate between imported months)
│   ├── Spending by category (horizontal bar chart)
│   ├── Weekly spending breakdown
│   └── Trend line across available months
├── Category detail view
│   ├── Click a category → see all transactions
│   ├── Monthly comparison for that category
│   └── Budget vs actual (if budget is set)
├── Recurring expenses panel
│   ├── Auto-detected recurring charges
│   ├── Monthly total of fixed costs
│   ├── Flag if a recurring charge changed amount
│   └── Link to optimisation suggestions
├── Transaction list view
│   ├── Filterable by month, category, amount range
│   ├── Searchable by description
│   ├── Inline recategorization
│   └── Flag as shared/holiday/recurring
├── Charts (Recharts or Chart.js)
│   ├── Spending over time (line chart)
│   ├── Category breakdown (donut or bar)
│   ├── Income vs expenses vs surplus (stacked bar)
│   └── Holiday vs home spending comparison
└── Verify: Dashboard renders with real data, all filters work, charts are accurate
```

**Design principle applied:** Dashboard is the "memory." It shows what the system knows at a glance. Chat is where you go for advice and action.

---

### Session 6: Progressive Profiling Engine (Day 8-10)
**Goal:** A system that knows what data is missing and collects it naturally through conversation.

```
Tasks:
├── Profile gap analyser
│   ├── Edge Function that computes which fields are empty
│   ├── Priority ranking: which gaps block the most valuable advice?
│   ├── Context rules: when is each question appropriate to ask?
│   │   ├── "Ask about partner only if dining/shared expenses detected"
│   │   ├── "Ask about goals only after baseline spending is established"
│   │   └── "Ask about investments only if savings surplus exists"
│   └── Returns next 1-2 questions to inject into chat context
├── Chat-integrated data collection
│   ├── When user starts a new chat, system checks for profile gaps
│   ├── If contextually appropriate, Claude weaves in a question
│   ├── Structured input components rendered inline in chat
│   │   ├── Single select (buttons)
│   │   ├── Multi-select
│   │   ├── Slider (risk tolerance, etc.)
│   │   ├── Number input (salary, rent)
│   │   └── Currency-aware amount input
│   ├── User response → function call → update user_profiles
│   └── Claude acknowledges the update and explains what it unlocks
├── Value exchange messaging
│   ├── Each question shows what the user gets by answering
│   ├── "Knowing your rent helps me calculate your true discretionary income"
│   ├── These rationales are stored in a questions config table
│   └── A/B testable — different phrasings for different users
├── Profile corrections flow
│   ├── "What do you know about me?" command in chat
│   ├── Renders current profile as structured cards
│   ├── Each field is editable inline
│   └── Corrections update the profile and recalculate analytics
└── Verify: New user who uploads CSV gets 3-4 questions over first two conversations. Profile builds naturally. User can view and correct everything.
```

---

### Session 7: Financial Tools — Claude Function Calling (Day 10-12)
**Goal:** Give Claude the ability to perform calculations, look up data, and take actions via function calling.

```
Tasks:
├── Define Claude tools (function calling)
│   ├── calculate_monthly_budget
│   │   ├── Input: user_id, month
│   │   ├── Queries: income, fixed costs, discretionary target
│   │   └── Returns: structured budget breakdown
│   ├── get_spending_summary
│   │   ├── Input: user_id, date_range, category (optional)
│   │   └── Returns: total, count, avg, top merchants, vs_budget
│   ├── compare_months
│   │   ├── Input: user_id, month_a, month_b
│   │   └── Returns: category-by-category comparison
│   ├── model_scenario
│   │   ├── Input: scenario_type, parameters
│   │   ├── Types: salary_increase, property_purchase, children, investment_growth
│   │   └── Returns: projected cash flow, timeline impact, goal impact
│   ├── search_bill_alternatives
│   │   ├── Input: bill_type, current_provider, current_amount, usage_details
│   │   ├── Uses web search to find alternatives
│   │   └── Returns: alternatives with estimated savings
│   ├── update_user_profile
│   │   ├── Input: field, value
│   │   ├── Validates before saving
│   │   └── Returns: confirmation + what this unlocks
│   ├── create_action_item
│   │   ├── Input: title, description, category, priority, due_date
│   │   └── Returns: created action item
│   └── get_action_items
│       ├── Input: user_id, status (optional)
│       └── Returns: list of action items with status
├── Tool execution layer (API route)
│   ├── Receives tool calls from Vercel AI SDK
│   ├── Executes against Supabase (authenticated)
│   ├── Returns structured results
│   └── Handles errors gracefully
├── Context injection refinement
│   ├── Before each chat, query relevant data
│   ├── Inject computed summaries, not raw data
│   ├── Token budget management (don't exceed context limits)
│   └── Priority: recent months > older months, active goals > completed
└── Verify: Ask Claude "how did my spending compare last month?" → it calls the tool → returns accurate answer. Ask to model a salary increase → runs calculation → presents results.
```

**Design principle applied:** "Don't rely on the LLM alone." Every number Claude presents comes from a system-computed function, not from Claude doing mental maths.

---

### Session 8: Monthly Review Flow (Day 12-13)
**Goal:** A structured monthly review that analyses the latest statement against the user's goals and budget.

```
Tasks:
├── Monthly review conversation type
│   ├── Triggered when new month's CSV is uploaded
│   ├── Or manually via "Start monthly review" button
│   ├── Uses a specialised system prompt
│   └── Structured flow: summary → highlights → concerns → actions
├── Review content
│   ├── Month overview (income, spending, surplus/deficit)
│   ├── Category performance vs budget
│   ├── Biggest wins and biggest overruns
│   ├── Comparison to previous month and 3-month average
│   ├── Holiday/exceptional spending flagged separately
│   ├── Progress toward goals
│   ├── Recurring bill changes detected
│   └── Updated action items (completed + new)
├── Review output
│   ├── Chat-based walkthrough with inline charts
│   ├── Summary card saved to monthly_snapshots
│   ├── New action items created
│   └── Financial portrait traits updated if patterns shift
└── Verify: Upload February statement → monthly review runs → identifies key changes → creates action items → updates dashboard
```

---

### Session 9: Bill Optimisation Engine (Day 13-15)
**Goal:** Proactively research better deals for the user's recurring bills.

```
Tasks:
├── Bill detection from transactions
│   ├── Auto-detect recurring charges by pattern
│   ├── Match to known providers (Iberdrola, Digi, Sanitas, etc.)
│   ├── Extract plan details from uploaded bills (images/PDFs)
│   └── Store in recurring_expenses with current_plan_details
├── Optimisation research
│   ├── Claude web search for alternatives (tariff comparison)
│   ├── Provider-specific research (Digi plans, Iberdrola vs TotalEnergies)
│   ├── Results stored with potential_saving_monthly
│   └── Recommendations surfaced in chat and dashboard
├── Contract monitoring
│   ├── Track contract end dates
│   ├── Nudge when contract approaching expiry
│   └── "Your Iberdrola contract ends next month — shall I research alternatives?"
├── Bill upload flow
│   ├── Upload a bill (image/PDF)
│   ├── Claude extracts key details (kWh, potencia, plan name, rate)
│   ├── Structured data saved to recurring_expenses
│   └── Comparison triggered automatically
└── Verify: Upload an Iberdrola bill → details extracted → alternatives researched → saving displayed on dashboard
```

---

### Session 10: Trip Planning & Scenario Modelling (Day 15-17)
**Goal:** The trip planning and scenario modelling features that were stress-tested in conversation.

```
Tasks:
├── Trip planning flow
│   ├── "Plan a trip" conversation type
│   ├── Collect: destination, duration, dates, travel style, companions
│   ├── Claude researches flights, accommodation, daily costs
│   ├── Budget breakdown with category-level estimates
│   ├── Funding plan: which months to save, what to cut
│   └── Trip saved as a goal with target amount and date
├── Scenario modelling
│   ├── Salary increase: recalculates surplus, savings trajectory, goal timelines
│   ├── Property purchase: deposit, mortgage, comparison with renting
│   ├── Children: phased cost model, impact on savings and goals
│   ├── Career change: models income gap, runway calculation
│   └── Each scenario shows before/after on key metrics
├── Scenario UI
│   ├── Chat-driven (natural language input)
│   ├── Results include inline charts
│   ├── Save/compare scenarios
│   └── "What happens if I get a raise AND have a kid?"
└── Verify: Ask to plan a Japan trip → get detailed budget with flight research → see funding plan. Model salary increase → see impact on retirement goal.
```

---

### Session 11: Nudge System & Proactive Intelligence (Day 17-19)
**Goal:** The system that reaches out to the user instead of waiting for them.

```
Tasks:
├── Nudge rules engine
│   ├── Payday transfer reminder (detect salary deposit → remind to save)
│   ├── Budget alert (spending approaching category limit)
│   ├── Bill due date reminder (3 days before)
│   ├── Contract expiry alert (30 days before)
│   ├── Monthly review prompt (7 days after month end)
│   ├── Action item reminder (after N days of inactivity)
│   └── Goal check-in (monthly progress update)
├── Nudge delivery
│   ├── In-app notification badge
│   ├── Email digest (weekly summary of nudges)
│   ├── Push notifications (future: mobile app)
│   └── Chat-initiated (nudge appears as a new chat message)
├── Nudge preferences
│   ├── User can control frequency and channels
│   ├── "Snooze" individual nudges
│   └── Smart frequency: back off if user ignores repeatedly
├── Scheduled jobs (pg_cron + Edge Functions)
│   ├── Daily: check for due nudges
│   ├── Weekly: spending pace check (are you on track for the month?)
│   ├── Monthly: generate monthly snapshot, trigger review
│   └── Quarterly: investment portfolio check, bill market comparison
└── Verify: Set up a payday nudge → when salary detected → notification appears → links to savings transfer action
```

---

### Session 12: Profile View & Trust Transparency (Day 19-20)
**Goal:** Let users see exactly what the system knows and control their data.

```
Tasks:
├── "What Claude knows about me" page
│   ├── Organised by category (basics, income, expenses, behavior, goals)
│   ├── Each field shows source (you told me, inferred from data, uploaded)
│   ├── Edit any field inline
│   ├── Delete any data point
│   └── Profile completeness visualisation
├── Financial portrait view
│   ├── Behavioral traits with evidence
│   ├── Spending patterns with data backing
│   ├── Confidence scores visible
│   └── "Is this accurate?" feedback buttons
├── Data management
│   ├── Export all data as JSON/CSV
│   ├── Delete account and all data
│   ├── View connected accounts
│   └── Import history log
├── Trust indicators throughout the app
│   ├── Chat: subtle indicator of what context Claude has
│   ├── Dashboard: data freshness indicator
│   ├── Recommendations: "Based on X months of data" label
│   └── Confidence levels on predictions
└── Verify: User can see their complete profile, edit any field, see behavioral traits, export data
```

---

### Session 13: Polish, Testing & Deploy (Day 20-22)
**Goal:** Production-ready deployment with Lewis as user #1.

```
Tasks:
├── Error handling
│   ├── CSV parsing failures (graceful feedback)
│   ├── Claude API failures (fallback messages)
│   ├── Network errors (offline indicator)
│   └── Invalid data entry (validation messages)
├── Performance
│   ├── Optimise dashboard queries (indexes on user_id + date)
│   ├── Lazy load chart components
│   ├── Streaming chat responses (already via Vercel AI SDK)
│   └── Edge caching for static assets
├── Mobile responsiveness
│   ├── Chat-first on mobile (dashboard secondary)
│   ├── Touch-friendly category selection
│   ├── CSV upload from phone (camera → PDF of statement)
│   └── Responsive charts
├── Security review
│   ├── RLS policies tested for every table
│   ├── API routes authenticated
│   ├── No PII in client-side logs
│   └── Claude API key server-side only
├── Seed Lewis's data
│   ├── Import all 6 months of Revolut CSVs
│   ├── Import Santander data
│   ├── Input investment holdings
│   ├── Set up recurring expenses from bill data
│   └── Populate financial portrait from stress test insights
└── Verify: Full end-to-end flow works. Lewis can use the app daily.
```

---

## Post-MVP Roadmap

### Fast Follow (Week 4-5)
- **Open Banking integration** (TrueLayer for EU) — automatic transaction ingestion
- **Investment tracking** — connect to broker APIs or manual portfolio input
- **Shared expenses** — split detection and tracking

### Medium Term (Month 2-3)
- **Mobile app** (React Native or PWA)
- **Push notifications** for nudges
- **Multi-currency dashboard** (EUR + GBP unified view)
- **Tax scenario modelling** (cross-border UK/Spain)

### Longer Term
- **Waitlist and onboarding for other users**
- **Partner financial profiles** (shared household view)
- **Bill switching automation** (one-click provider switch)
- **Investment rebalancing suggestions**

---

## Key Files Structure

```
/app
  /api
    /chat/route.ts          ← Vercel AI SDK chat handler
    /upload/route.ts        ← CSV upload endpoint
    /tools/[tool]/route.ts  ← Claude function execution
    /cron/[job]/route.ts    ← Scheduled job handlers
  /(auth)
    /login/page.tsx
    /signup/page.tsx
  /(app)
    /layout.tsx             ← Authenticated layout with nav
    /chat/page.tsx          ← Chat interface
    /chat/[id]/page.tsx     ← Specific conversation
    /dashboard/page.tsx     ← Financial overview
    /transactions/page.tsx  ← Transaction list
    /goals/page.tsx         ← Goals tracker
    /bills/page.tsx         ← Recurring expenses
    /profile/page.tsx       ← "What Claude knows about me"
    /settings/page.tsx      ← Preferences, data management
/lib
  /supabase
    /client.ts              ← Supabase client setup
    /queries.ts             ← Reusable query functions
    /types.ts               ← Generated types from schema
  /chat
    /system-prompt.ts       ← System prompt builder
    /context-builder.ts     ← Injects user data into prompt
    /tools.ts               ← Claude tool definitions
  /parsers
    /revolut.ts             ← Revolut CSV parser
    /santander.ts           ← Santander XLSX parser
    /generic.ts             ← Generic CSV with mapping
  /categorizer
    /rules.ts               ← Pattern-matching rules engine
    /llm-categorizer.ts     ← Claude fallback for unmatched
  /analytics
    /monthly-snapshot.ts    ← Compute monthly summary
    /recurring-detector.ts  ← Find recurring transactions
    /holiday-detector.ts    ← Cluster foreign spending
  /nudges
    /rules.ts               ← Nudge trigger definitions
    /scheduler.ts           ← Cron job logic
/components
  /chat
    /ChatInterface.tsx
    /MessageBubble.tsx
    /StructuredInput.tsx    ← Buttons, sliders, selects in chat
    /TypingIndicator.tsx
  /dashboard
    /SpendingChart.tsx
    /CategoryBreakdown.tsx
    /MonthlyCards.tsx
    /TrendLine.tsx
  /upload
    /CSVUploader.tsx
    /TransactionPreview.tsx
  /profile
    /ProfileCard.tsx
    /TraitDisplay.tsx
    /EditableField.tsx
/supabase
  /migrations
    /001_initial_schema.sql
    /002_rls_policies.sql
    /003_default_categories.sql
    /004_functions.sql
```

---

## Stress Test Learnings → Implementation Mappings

| Learning | Implementation |
|----------|---------------|
| W1: LLM can't do maths reliably | All calculations in Edge Functions, injected as context |
| W2: Tool broke, data lost | Progressive save — every answer persists immediately |
| W3: Assumptions wrong until corrected | Explicit confirmation steps, easy correction flow |
| W4: No persistence between sessions | Full conversation + profile storage in Supabase |
| W5: Can't initiate contact | Nudge system with pg_cron |
| W6: Manual CSV upload is friction | CSV first, bank API fast follow |
| W7: Research results go stale | Recurring bill check scheduled quarterly |
| S1: Conversation beats forms | Chat-first onboarding with structured inputs inline |
| S2: Corrections improve accuracy | Correction flow feeds back into rules and profile |
| S3: Aha moment is key activation | Post-CSV analysis is the first thing users see |
| S4: Behavioral insights are the moat | Financial portrait table built over time |
| S5: Real-time research adds value | Claude web search integrated via tools |
| S6: Honesty builds trust | Confidence scores visible, limitations acknowledged |
| O1: Financial portrait as differentiator | Dedicated table with trait tracking |
| O2: Aha moment as activation metric | Tracked as a product event |
| O5: Auto-pilot for boring stuff | Background processing pipeline |
| O7: Social spending management | Shared expense detection and calendar integration |
| O8: Credit card bridge pattern | Cash flow timeline with payment recommendations |
