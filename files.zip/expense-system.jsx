import { useState, useEffect, useCallback } from "react";

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const CURRENT_MONTH = new Date().getMonth();
const CURRENT_YEAR = new Date().getFullYear();

const DEFAULT_CATEGORIES = [
  { id: "groceries", label: "Groceries", icon: "G", budget: 280, color: "#1D9E75" },
  { id: "dining", label: "Dining & bars", icon: "D", budget: 260, color: "#D85A30" },
  { id: "travel", label: "Travel & flights", icon: "T", budget: 200, color: "#E24B4A" },
  { id: "entertainment", label: "Entertainment", icon: "E", budget: 80, color: "#534AB7" },
  { id: "golf", label: "Golf & sport", icon: "S", budget: 65, color: "#378ADD" },
  { id: "shopping", label: "Shopping", icon: "P", budget: 60, color: "#BA7517" },
  { id: "transport", label: "Local transport", icon: "R", budget: 50, color: "#D4537E" },
  { id: "other", label: "Other", icon: "O", budget: 55, color: "#888780" },
];

const TOTAL_MONTHLY_BUDGET = DEFAULT_CATEGORIES.reduce((s, c) => s + c.budget, 0);
const WEEKLY_BUDGET = Math.round(TOTAL_MONTHLY_BUDGET / 4.33);

const PAY_STRUCTURE = {
  regular: 2700,
  doublePay: 5400,
  bonusMonth: 6700,
  fixedCosts: 1400,
};

const MONTH_TYPES = {
  0: "regular", 1: "regular", 2: "bonus", 3: "regular", 4: "regular",
  5: "double", 6: "regular", 7: "regular", 8: "regular", 9: "regular",
  10: "double", 11: "regular",
};

function getMonthIncome(monthIdx) {
  const type = MONTH_TYPES[monthIdx];
  if (type === "bonus") return PAY_STRUCTURE.bonusMonth;
  if (type === "double") return PAY_STRUCTURE.doublePay;
  return PAY_STRUCTURE.regular;
}

function getMonthSavingsTarget(monthIdx) {
  const income = getMonthIncome(monthIdx);
  return income - PAY_STRUCTURE.fixedCosts - TOTAL_MONTHLY_BUDGET;
}

function fmt(n) {
  return Math.round(n).toLocaleString("en-ES");
}

function StorageManager() {
  return {
    async load(key) {
      try {
        const r = await window.storage.get(key);
        return r ? JSON.parse(r.value) : null;
      } catch { return null; }
    },
    async save(key, data) {
      try {
        await window.storage.set(key, JSON.stringify(data));
      } catch (e) { console.error("Save failed:", e); }
    }
  };
}

function ProgressRing({ pct, color, size = 44, stroke = 4 }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const clamped = Math.min(Math.max(pct, 0), 100);
  const offset = circ - (clamped / 100) * circ;
  const isOver = pct > 100;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none"
        stroke="var(--color-border-tertiary)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none"
        stroke={isOver ? "#E24B4A" : color} strokeWidth={stroke}
        strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 0.4s ease" }} />
    </svg>
  );
}

function WeekIndicator({ weekNum, spent, budget }) {
  const pct = budget > 0 ? (spent / budget) * 100 : 0;
  const remaining = budget - spent;
  return (
    <div style={{
      flex: 1, padding: "10px 12px",
      background: remaining < 0 ? "var(--color-background-danger)" : "var(--color-background-primary)",
      border: "0.5px solid var(--color-border-tertiary)",
      borderRadius: "var(--border-radius-md)",
      textAlign: "center",
    }}>
      <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 4 }}>Week {weekNum}</div>
      <div style={{ fontSize: 16, fontWeight: 500, color: remaining < 0 ? "var(--color-text-danger)" : "var(--color-text-primary)" }}>
        €{fmt(spent)}
      </div>
      <div style={{ fontSize: 11, color: remaining < 0 ? "var(--color-text-danger)" : "var(--color-text-success)" }}>
        {remaining >= 0 ? `€${fmt(remaining)} left` : `€${fmt(Math.abs(remaining))} over`}
      </div>
    </div>
  );
}

export default function ExpenseSystem() {
  const [view, setView] = useState("dashboard");
  const [selectedMonth, setSelectedMonth] = useState(CURRENT_MONTH);
  const [expenses, setExpenses] = useState([]);
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [loaded, setLoaded] = useState(false);
  const [addingExpense, setAddingExpense] = useState(false);
  const [newExp, setNewExp] = useState({ amount: "", category: "dining", note: "", day: new Date().getDate() });
  const [editingBudget, setEditingBudget] = useState(false);
  const [budgetDrafts, setBudgetDrafts] = useState({});

  const storage = StorageManager();
  const monthKey = `expenses-${CURRENT_YEAR}-${selectedMonth}`;

  useEffect(() => {
    (async () => {
      const saved = await storage.load(monthKey);
      if (saved) setExpenses(saved);
      else setExpenses([]);
      const savedCats = await storage.load("budget-categories");
      if (savedCats) setCategories(savedCats);
      setLoaded(true);
    })();
  }, [monthKey]);

  const saveExpenses = useCallback(async (exps) => {
    setExpenses(exps);
    await storage.save(monthKey, exps);
  }, [monthKey]);

  const saveBudgets = useCallback(async (cats) => {
    setCategories(cats);
    await storage.save("budget-categories", cats);
  }, []);

  function addExpense() {
    if (!newExp.amount) return;
    const exp = {
      id: Date.now(),
      amount: parseFloat(newExp.amount) || 0,
      category: newExp.category,
      note: newExp.note,
      day: parseInt(newExp.day) || new Date().getDate(),
      ts: Date.now(),
    };
    const updated = [...expenses, exp];
    saveExpenses(updated);
    setNewExp({ amount: "", category: "dining", note: "", day: new Date().getDate() });
    setAddingExpense(false);
  }

  function deleteExpense(id) {
    saveExpenses(expenses.filter(e => e.id !== id));
  }

  function getWeek(day) {
    if (day <= 7) return 1;
    if (day <= 14) return 2;
    if (day <= 21) return 3;
    return 4;
  }

  const totalSpent = expenses.reduce((s, e) => s + e.amount, 0);
  const totalBudget = categories.reduce((s, c) => s + c.budget, 0);
  const remaining = totalBudget - totalSpent;
  const weeklyBudget = Math.round(totalBudget / 4.33);
  const weekSpending = [1,2,3,4].map(w =>
    expenses.filter(e => getWeek(e.day) === w).reduce((s,e) => s + e.amount, 0)
  );
  const monthIncome = getMonthIncome(selectedMonth);
  const savingsTarget = getMonthSavingsTarget(selectedMonth);
  const monthType = MONTH_TYPES[selectedMonth];
  const daysInMonth = new Date(CURRENT_YEAR, selectedMonth + 1, 0).getDate();
  const today = selectedMonth === CURRENT_MONTH ? new Date().getDate() : daysInMonth;
  const dailyBudgetRemaining = remaining > 0 && (daysInMonth - today) > 0 ? remaining / (daysInMonth - today) : 0;

  if (!loaded) return <div style={{ padding: "2rem", textAlign: "center", color: "var(--color-text-secondary)" }}>Loading...</div>;

  return (
    <div style={{ maxWidth: 660, margin: "0 auto", padding: "0.5rem 0" }}>
      <div style={{ display: "flex", gap: 4, marginBottom: "1.25rem" }}>
        {["dashboard", "log", "plan"].map(v => (
          <button key={v} onClick={() => setView(v)} style={{
            padding: "6px 14px", fontSize: 12, fontWeight: view === v ? 500 : 400,
            background: view === v ? "var(--color-text-primary)" : "transparent",
            color: view === v ? "var(--color-background-primary)" : "var(--color-text-secondary)",
            border: view === v ? "none" : "0.5px solid var(--color-border-tertiary)",
            borderRadius: "var(--border-radius-md)", cursor: "pointer",
            textTransform: "capitalize",
          }}>{v === "plan" ? "Annual plan" : v}</button>
        ))}
        <div style={{ flex: 1 }} />
        <select value={selectedMonth} onChange={e => setSelectedMonth(parseInt(e.target.value))}
          style={{ fontSize: 12, padding: "4px 10px", borderRadius: "var(--border-radius-md)",
            border: "0.5px solid var(--color-border-tertiary)", background: "var(--color-background-primary)",
            color: "var(--color-text-primary)" }}>
          {MONTHS.map((m, i) => <option key={i} value={i}>{m} {CURRENT_YEAR}</option>)}
        </select>
      </div>

      {view === "dashboard" && (
        <div>
          <div style={{
            background: remaining >= 0 ? "var(--color-background-primary)" : "var(--color-background-danger)",
            border: "0.5px solid var(--color-border-tertiary)",
            borderRadius: "var(--border-radius-lg)", padding: "1.25rem", marginBottom: 12,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
              <div>
                <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 2 }}>
                  {MONTHS[selectedMonth]} spending card budget
                </div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                  <span style={{ fontSize: 28, fontWeight: 500 }}>€{fmt(totalSpent)}</span>
                  <span style={{ fontSize: 14, color: "var(--color-text-secondary)" }}>/ €{fmt(totalBudget)}</span>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 12, color: remaining >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)", marginBottom: 2 }}>
                  {remaining >= 0 ? "Remaining" : "Over budget"}
                </div>
                <div style={{
                  fontSize: 22, fontWeight: 500,
                  color: remaining >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)"
                }}>€{fmt(Math.abs(remaining))}</div>
              </div>
            </div>
            <div style={{ height: 6, background: "var(--color-background-secondary)", borderRadius: 3, overflow: "hidden", marginBottom: 12 }}>
              <div style={{
                height: "100%", borderRadius: 3,
                width: `${Math.min((totalSpent / totalBudget) * 100, 100)}%`,
                background: totalSpent > totalBudget ? "#E24B4A" : totalSpent > totalBudget * 0.8 ? "#BA7517" : "#1D9E75",
                transition: "width 0.4s ease",
              }} />
            </div>
            {dailyBudgetRemaining > 0 && selectedMonth === CURRENT_MONTH && (
              <div style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>
                ~€{fmt(dailyBudgetRemaining)}/day for the rest of the month
              </div>
            )}
          </div>

          {monthType !== "regular" && (
            <div style={{
              padding: "12px 16px", marginBottom: 12,
              background: "var(--color-background-success)",
              borderRadius: "var(--border-radius-md)",
              display: "flex", justifyContent: "space-between", alignItems: "center",
            }}>
              <div>
                <div style={{ fontSize: 12, color: "var(--color-text-success)" }}>
                  {monthType === "bonus" ? "Bonus month" : "Double pay month"} — save first
                </div>
                <div style={{ fontSize: 15, fontWeight: 500, color: "var(--color-text-success)" }}>
                  Transfer €{fmt(savingsTarget)} before spending
                </div>
              </div>
              <div style={{ fontSize: 20 }}>→</div>
            </div>
          )}

          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            {[1,2,3,4].map(w => (
              <WeekIndicator key={w} weekNum={w} spent={weekSpending[w-1]} budget={weeklyBudget} />
            ))}
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <span style={{ fontSize: 14, fontWeight: 500 }}>Category budgets</span>
            <button onClick={() => { setEditingBudget(!editingBudget); setBudgetDrafts(Object.fromEntries(categories.map(c => [c.id, c.budget]))); }}
              style={{ fontSize: 12, padding: "4px 10px", background: "transparent",
                border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)",
                cursor: "pointer", color: "var(--color-text-secondary)" }}>
              {editingBudget ? "Cancel" : "Edit budgets"}
            </button>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {categories.map(cat => {
              const spent = expenses.filter(e => e.category === cat.id).reduce((s,e) => s + e.amount, 0);
              const pct = cat.budget > 0 ? (spent / cat.budget) * 100 : 0;
              const catRemaining = cat.budget - spent;
              return (
                <div key={cat.id} style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "8px 12px",
                  background: "var(--color-background-primary)",
                  border: "0.5px solid var(--color-border-tertiary)",
                  borderRadius: "var(--border-radius-md)",
                }}>
                  <div style={{ position: "relative", width: 44, height: 44, flexShrink: 0 }}>
                    <ProgressRing pct={pct} color={cat.color} />
                    <div style={{
                      position: "absolute", inset: 0, display: "flex", alignItems: "center",
                      justifyContent: "center", fontSize: 11, fontWeight: 500, color: cat.color,
                    }}>{Math.round(pct)}%</div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                      <span style={{ fontSize: 13, fontWeight: 500 }}>{cat.label}</span>
                      <span style={{ fontSize: 12, color: catRemaining >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)" }}>
                        {catRemaining >= 0 ? `€${fmt(catRemaining)} left` : `€${fmt(Math.abs(catRemaining))} over`}
                      </span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>€{fmt(spent)} spent</span>
                      {editingBudget ? (
                        <input type="number" value={budgetDrafts[cat.id] ?? cat.budget}
                          onChange={e => setBudgetDrafts({...budgetDrafts, [cat.id]: parseInt(e.target.value) || 0})}
                          style={{ width: 70, fontSize: 12, padding: "2px 6px", textAlign: "right" }} />
                      ) : (
                        <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>€{fmt(cat.budget)} budget</span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {editingBudget && (
            <button onClick={() => {
              const updated = categories.map(c => ({...c, budget: budgetDrafts[c.id] ?? c.budget}));
              saveBudgets(updated);
              setEditingBudget(false);
            }} style={{
              marginTop: 10, width: "100%", padding: "10px",
              background: "var(--color-text-primary)", color: "var(--color-background-primary)",
              border: "none", borderRadius: "var(--border-radius-md)", cursor: "pointer",
              fontSize: 13, fontWeight: 500,
            }}>Save budgets (new total: €{fmt(Object.values(budgetDrafts).reduce((s,v) => s + (v||0), 0))})</button>
          )}

          <button onClick={() => { setAddingExpense(true); setView("log"); }}
            style={{
              marginTop: 12, width: "100%", padding: "12px",
              background: "var(--color-text-primary)", color: "var(--color-background-primary)",
              border: "none", borderRadius: "var(--border-radius-md)", cursor: "pointer",
              fontSize: 14, fontWeight: 500,
            }}>+ Log expense</button>
        </div>
      )}

      {view === "log" && (
        <div>
          {(addingExpense || expenses.length === 0) && (
            <div style={{
              padding: "1.25rem", marginBottom: 16,
              background: "var(--color-background-primary)",
              border: "0.5px solid var(--color-border-tertiary)",
              borderRadius: "var(--border-radius-lg)",
            }}>
              <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 12 }}>Add expense</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                <div style={{ display: "flex", gap: 8 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>Amount (€)</div>
                    <input type="number" placeholder="0" value={newExp.amount}
                      onChange={e => setNewExp({...newExp, amount: e.target.value})}
                      style={{ width: "100%", fontSize: 16 }} />
                  </div>
                  <div style={{ width: 70 }}>
                    <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>Day</div>
                    <input type="number" min="1" max="31" value={newExp.day}
                      onChange={e => setNewExp({...newExp, day: e.target.value})}
                      style={{ width: "100%", fontSize: 16 }} />
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>Category</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                    {categories.map(c => (
                      <button key={c.id} onClick={() => setNewExp({...newExp, category: c.id})}
                        style={{
                          padding: "6px 10px", fontSize: 12,
                          background: newExp.category === c.id ? c.color : "transparent",
                          color: newExp.category === c.id ? "white" : "var(--color-text-secondary)",
                          border: `0.5px solid ${newExp.category === c.id ? c.color : "var(--color-border-tertiary)"}`,
                          borderRadius: "var(--border-radius-md)", cursor: "pointer",
                        }}>{c.label}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>Note (optional)</div>
                  <input type="text" placeholder="e.g. Aldi weekly shop" value={newExp.note}
                    onChange={e => setNewExp({...newExp, note: e.target.value})}
                    style={{ width: "100%", fontSize: 14 }} />
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={addExpense} style={{
                    flex: 1, padding: "10px", background: "var(--color-text-primary)",
                    color: "var(--color-background-primary)", border: "none",
                    borderRadius: "var(--border-radius-md)", cursor: "pointer",
                    fontSize: 13, fontWeight: 500,
                  }}>Add</button>
                  <button onClick={() => setAddingExpense(false)} style={{
                    padding: "10px 16px", background: "transparent",
                    border: "0.5px solid var(--color-border-tertiary)",
                    borderRadius: "var(--border-radius-md)", cursor: "pointer",
                    fontSize: 13, color: "var(--color-text-secondary)",
                  }}>Cancel</button>
                </div>
              </div>
            </div>
          )}

          {!addingExpense && expenses.length > 0 && (
            <button onClick={() => setAddingExpense(true)} style={{
              width: "100%", padding: "10px", marginBottom: 12,
              background: "var(--color-text-primary)", color: "var(--color-background-primary)",
              border: "none", borderRadius: "var(--border-radius-md)", cursor: "pointer",
              fontSize: 13, fontWeight: 500,
            }}>+ Add expense</button>
          )}

          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {[...expenses].sort((a,b) => b.day - a.day || b.ts - a.ts).map(exp => {
              const cat = categories.find(c => c.id === exp.category);
              return (
                <div key={exp.id} style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "10px 12px",
                  background: "var(--color-background-primary)",
                  border: "0.5px solid var(--color-border-tertiary)",
                  borderRadius: "var(--border-radius-md)",
                }}>
                  <div style={{
                    width: 8, height: 8, borderRadius: "50%",
                    background: cat?.color || "#888", flexShrink: 0,
                  }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>
                      {exp.note || cat?.label}
                    </div>
                    <div style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>
                      Day {exp.day} · {cat?.label}
                    </div>
                  </div>
                  <span style={{ fontSize: 14, fontWeight: 500 }}>€{fmt(exp.amount)}</span>
                  <button onClick={() => deleteExpense(exp.id)} style={{
                    padding: "2px 6px", fontSize: 11, background: "transparent",
                    border: "0.5px solid var(--color-border-tertiary)", borderRadius: 4,
                    cursor: "pointer", color: "var(--color-text-danger)",
                  }}>×</button>
                </div>
              );
            })}
            {expenses.length === 0 && !addingExpense && (
              <div style={{ padding: "2rem", textAlign: "center", color: "var(--color-text-tertiary)", fontSize: 13 }}>
                No expenses logged for {MONTHS[selectedMonth]} yet
              </div>
            )}
          </div>
        </div>
      )}

      {view === "plan" && (
        <div>
          <div style={{
            padding: "1.25rem", marginBottom: 16,
            background: "var(--color-background-primary)",
            border: "0.5px solid var(--color-border-tertiary)",
            borderRadius: "var(--border-radius-lg)",
          }}>
            <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 4 }}>Annual savings projection</div>
            <div style={{ fontSize: 13, color: "var(--color-text-secondary)", marginBottom: 16, lineHeight: 1.6 }}>
              If you stick to the €{fmt(totalBudget)}/month spending budget and save from the three big pay months:
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 10, marginBottom: 16 }}>
              <div style={{ background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: 12, textAlign: "center" }}>
                <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 2 }}>Monthly surplus</div>
                <div style={{ fontSize: 18, fontWeight: 500, color: "var(--color-text-success)" }}>€{fmt(PAY_STRUCTURE.regular - PAY_STRUCTURE.fixedCosts - totalBudget)}</div>
                <div style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>× 9 regular months</div>
              </div>
              <div style={{ background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: 12, textAlign: "center" }}>
                <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 2 }}>Double pay extra</div>
                <div style={{ fontSize: 18, fontWeight: 500, color: "var(--color-text-success)" }}>€{fmt(2700)}</div>
                <div style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>× 2 months (Jun, Nov)</div>
              </div>
              <div style={{ background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: 12, textAlign: "center" }}>
                <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 2 }}>Bonus extra</div>
                <div style={{ fontSize: 18, fontWeight: 500, color: "var(--color-text-success)" }}>€{fmt(4000)}</div>
                <div style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>March</div>
              </div>
            </div>
            <div style={{
              padding: "14px 16px", background: "var(--color-background-success)",
              borderRadius: "var(--border-radius-md)", textAlign: "center",
            }}>
              <div style={{ fontSize: 12, color: "var(--color-text-success)", marginBottom: 2 }}>Projected annual savings</div>
              <div style={{ fontSize: 26, fontWeight: 500, color: "var(--color-text-success)" }}>
                €{fmt(
                  (PAY_STRUCTURE.regular - PAY_STRUCTURE.fixedCosts - totalBudget) * 9 +
                  (PAY_STRUCTURE.doublePay - PAY_STRUCTURE.fixedCosts - totalBudget) * 2 +
                  (PAY_STRUCTURE.bonusMonth - PAY_STRUCTURE.fixedCosts - totalBudget)
                )}
              </div>
              <div style={{ fontSize: 12, color: "var(--color-text-success)" }}>
                ~£{fmt(
                  ((PAY_STRUCTURE.regular - PAY_STRUCTURE.fixedCosts - totalBudget) * 9 +
                  (PAY_STRUCTURE.doublePay - PAY_STRUCTURE.fixedCosts - totalBudget) * 2 +
                  (PAY_STRUCTURE.bonusMonth - PAY_STRUCTURE.fixedCosts - totalBudget)) * 0.85
                )} after FX conversion
              </div>
            </div>
          </div>

          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 10 }}>Month-by-month</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {MONTHS.map((m, i) => {
              const inc = getMonthIncome(i);
              const sav = getMonthSavingsTarget(i);
              const type = MONTH_TYPES[i];
              return (
                <div key={i} style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "8px 12px",
                  background: i === selectedMonth ? "var(--color-background-info)" : "var(--color-background-primary)",
                  border: "0.5px solid var(--color-border-tertiary)",
                  borderRadius: "var(--border-radius-md)",
                }}>
                  <span style={{ fontSize: 13, fontWeight: 500, minWidth: 32 }}>{m}</span>
                  <span style={{ fontSize: 12, color: "var(--color-text-secondary)", minWidth: 70 }}>€{fmt(inc)}</span>
                  {type !== "regular" && (
                    <span style={{
                      fontSize: 10, padding: "2px 6px",
                      background: type === "bonus" ? "var(--color-background-warning)" : "var(--color-background-success)",
                      color: type === "bonus" ? "var(--color-text-warning)" : "var(--color-text-success)",
                      borderRadius: "var(--border-radius-md)",
                    }}>{type === "bonus" ? "Bonus" : "Double"}</span>
                  )}
                  <div style={{ flex: 1 }} />
                  <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>-€{fmt(PAY_STRUCTURE.fixedCosts)} fixed</span>
                  <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>-€{fmt(totalBudget)} card</span>
                  <span style={{
                    fontSize: 13, fontWeight: 500, minWidth: 60, textAlign: "right",
                    color: sav >= 0 ? "var(--color-text-success)" : "var(--color-text-danger)",
                  }}>€{fmt(sav)}</span>
                </div>
              );
            })}
          </div>

          <div style={{
            marginTop: 16, padding: "14px 16px",
            background: "var(--color-background-secondary)",
            borderRadius: "var(--border-radius-md)",
            fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.7,
          }}>
            <div style={{ fontWeight: 500, color: "var(--color-text-primary)", marginBottom: 4 }}>The system in three rules</div>
            1. On payday, transfer the savings target immediately — before the credit card bill lands.<br/>
            2. Load only €{fmt(totalBudget)} onto your spending card for the month. When it's gone, it's gone.<br/>
            3. Review this dashboard each Sunday. If a category is running hot, adjust the rest of the month.
          </div>
        </div>
      )}
    </div>
  );
}
