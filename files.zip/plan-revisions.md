# Implementation Plan — Revisions

## Key Changes from Original Plan

### 1. Build Approach: Fresh project with surgical transplants from v1

**New repo, new Supabase project, clean schema.** For each v1 module:
- Open v1 file alongside the new architecture
- If the file is clean and aligns with the new schema → copy and adapt
- If the logic is right but the code is tangled → rewrite using v1 as pseudocode
- If fundamentally different in the new design → write fresh

**Estimated time saving:** ~5 days (22 → 17 days), with the buffer going to polish and edge cases.

---

### 2. Tech Stack Adjustment: Bedrock instead of direct Claude API

```
Before:  Vercel AI SDK → Claude API (direct)
After:   Vercel AI SDK → AWS Bedrock → Claude Sonnet 4.6
```

Vercel AI SDK supports Bedrock as a provider via the `@ai-sdk/amazon-bedrock` package. The chat UI, streaming, and tool calling all work the same — only the backend connection changes.

```typescript
// lib/ai/provider.ts
import { createAmazonBedrock } from '@ai-sdk/amazon-bedrock';

export const bedrock = createAmazonBedrock({
  region: process.env.AWS_REGION,
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

export const chatModel = bedrock('anthropic.claude-sonnet-4-6-20250514-v1:0');
export const analysisModel = bedrock('anthropic.claude-sonnet-4-6-20250514-v1:0');
```

**Implication:** Environment variables change (AWS credentials instead of Anthropic API key). Function calling format may need slight adaptation for Bedrock's tool use implementation. Test early in Session 2.

---

### 3. Dual Categorisation System

Every transaction gets TWO classifications:

**Traditional category** (objective, auto-assigned):
- Groceries, Dining, Transport, Travel, Entertainment, Shopping, Health, Bills, etc.
- Assigned by rules engine first, LLM fallback for unmatched
- Used for: budget tracking, month-over-month comparison, spending breakdown

**Value category** (subjective, user-influenced):
- Foundation: essential to daily functioning
- Burden: necessary but resented
- Investment: builds future value (financial, personal, relational)
- Leak: wasteful or regretted
- Unclassified: not yet categorised

The value category is what makes this app different from every competitor.

#### Schema changes

```sql
-- Add value_category to transactions
alter table transactions add column value_category text; 
-- 'foundation', 'burden', 'investment', 'leak', null

-- Value Map results (from onboarding)
create table value_map_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  
  -- Raw interaction data
  responses jsonb not null,
  -- [{
  --   transaction: "PureGym Monthly",
  --   category: "investment",
  --   confidence: 3,
  --   time_to_decide_ms: 4200,
  --   changed_mind: false,
  --   original_category: null
  -- }]
  
  -- Generated profile
  archetype_name text, -- "The Drifter"
  archetype_subtitle text, -- "Your money moves without a plan"
  full_analysis text, -- Claude's personality reading
  
  -- Derived patterns (extracted from Claude's analysis)
  certainty_areas jsonb, -- categories where confidence was high
  conflict_areas jsonb, -- categories where they hesitated or changed mind
  comfort_patterns jsonb, -- what they consider Foundation
  
  -- Metadata
  country text,
  completed_at timestamptz default now(),
  created_at timestamptz default now()
);

-- Category mapping preferences (learned over time)
create table value_category_rules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  
  -- Either a traditional category or specific merchant pattern
  match_type text not null, -- 'traditional_category', 'merchant', 'description_pattern'
  match_value text not null, -- 'dining', 'PureGym', 'Aldi|Mercadona'
  
  value_category text not null, -- 'foundation', 'burden', 'investment', 'leak'
  confidence numeric default 0.5,
  source text, -- 'value_map', 'user_explicit', 'inferred'
  
  created_at timestamptz default now()
);
```

#### How value categories get assigned

**Layer 1 — Value Map seed:** When the user completes the Value Map, their categorization patterns create initial rules. If they called gym spending "Investment" and coffee "Foundation", those become baseline mappings.

**Layer 2 — Auto-inference:** For imported transactions, the system checks `value_category_rules` first. "Aldi" maps to whatever the user's grocery value category is (probably "Foundation").

**Layer 3 — User refinement:** In the transaction view, users can tag or re-tag any transaction's value category. These corrections feed back into the rules.

**Layer 4 — Claude insight:** During monthly reviews, Claude can observe: "You tagged 80% of your dining as Investment last month, but this month it's split 50/50 Investment and Leak. What changed?" This surfaces behavioral shifts the user might not notice.

#### Dashboard views

The dashboard gets a toggle: **Spending View** (traditional categories) | **Values View** (Foundation/Burden/Investment/Leak)

**Spending View:** Standard breakdown — "You spent €416 on dining, €274 on groceries..."

**Values View:** "62% of your spending is Foundation (essentials), 18% is Investment (things building your future), 12% is Leak (things you'd cut if you could), 8% is Burden (things you resent but can't avoid)."

The Values View is where the emotional resonance lives. Seeing that 12% of your money is going to things you consider wasteful is far more motivating than seeing a generic "Entertainment: €535" line.

---

### 4. Value Map as Onboarding Funnel

The Value Map moves from standalone demo to integrated onboarding:

```
┌─────────────────────────────────────────────┐
│  Marketing / Sharing                        │
│  "Take the Value Map → share your archetype"│
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│  Value Map Experience (no signup required)   │
│  10 transactions → personality reading      │
│  Captures: categories, confidence, timing   │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│  Conversion prompt                          │
│  "Want to see what your real spending says? │
│   Upload a statement and find out."         │
└──────────────────┬──────────────────────────┘
                   │ (signup happens here)
                   ▼
┌─────────────────────────────────────────────┐
│  CSV Upload → Auto-analysis                 │
│  Traditional + Value categorisation         │
│  "The Gap" — self-perception vs reality     │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│  Full app experience                        │
│  Chat + Dashboard + Progressive profiling   │
└─────────────────────────────────────────────┘
```

**"The Gap"** is the second aha moment. The Value Map told them what they believe about their spending. The CSV analysis shows them the truth. The difference between those two is where the deepest insights live, and it's the moment the user thinks: "this app actually understands me."

**Implementation:** The Value Map results are stored in `value_map_results` linked to an anonymous session. When the user signs up, the session is linked to their account and the data seeds their `financial_portrait` and `value_category_rules`.

---

### 5. Revised Session Plan

#### Session 1: Foundation + Value Map Integration (Day 1-2)
```
Tasks:
├── New Next.js project with App Router
├── New Supabase project with clean schema (all migrations)
├── Vercel deployment configured
├── Auth (port from v1, should be quick)
├── Layout shell with navigation
├── Port Value Map into /demo route
│   ├── Move from standalone to integrated
│   ├── Anonymous session tracking (store results before signup)
│   ├── Connect to Bedrock (already working in v1)
│   └── Ensure personality reading generates correctly
└── Conversion flow: Value Map → signup prompt → account creation
```

#### Session 2: Chat Foundation on Bedrock (Day 2-3)
```
Tasks:
├── Install @ai-sdk/amazon-bedrock
├── Port chat UI from v1 (refactor for cleanliness)
├── /api/chat route handler with Bedrock streaming
├── Conversation persistence in Supabase
├── System prompt architecture
│   ├── Context injection points defined
│   ├── Financial portrait data included when available
│   └── Value Map archetype included if completed
└── Test: multi-turn conversation works with streaming
```

#### Session 3: CSV Engine + Dual Categorisation (Day 3-5)
```
Tasks:
├── Port CSV parsers from v1 (Revolut, Santander)
├── Port auto-categorisation rules engine from v1
├── NEW: Value category assignment layer
│   ├── Check value_category_rules for user
│   ├── If Value Map completed: apply seed rules
│   ├── If no rules: leave value_category null (ask later)
│   └── Confidence scoring for both category types
├── Transaction storage with dual categories
├── Duplicate detection
├── Monthly snapshot computation (Edge Function)
└── Test: upload CSV → transactions categorised both ways
```

#### Session 4: The Double Aha Moment (Day 5-6)
```
Tasks:
├── Post-CSV analysis chat trigger
│   ├── Inject spending breakdown + value breakdown
│   ├── If Value Map completed: "The Gap" analysis
│   │   ├── Compare self-perception with actual spending
│   │   ├── "You called gym spending Investment but you haven't been in 6 weeks"
│   │   └── "You tagged coffee as Foundation — and you spend €X/month on it"
│   └── If no Value Map: standard spending insight
├── Structured follow-up questions (2-3 max)
├── Profile updates from answers
├── Financial portrait seeding
│   ├── From Value Map: archetype, certainty areas, conflicts
│   ├── From CSV: actual patterns, holiday vs home, frequency
│   └── From The Gap: where perception ≠ reality
└── Test: full flow from Value Map → signup → CSV → double aha moment
```

#### Session 5: Dashboard with Dual Views (Day 6-8)
```
Tasks:
├── Spending View (traditional categories)
│   ├── Port chart components from v1
│   ├── Monthly summary cards
│   ├── Category breakdown
│   └── Trend lines
├── NEW: Values View (Foundation/Burden/Investment/Leak)
│   ├── Proportional breakdown visualisation
│   ├── "Your money is..." summary statement
│   ├── Drill-down into each value category
│   └── Uncategorised transactions queue
├── Toggle between views
├── Transaction list with dual category display
├── Inline recategorisation (both types)
└── Month navigation
```

#### Session 6: Progressive Profiling (Day 8-10)
```
Largely unchanged from original plan.
Added: Value Map data informs which questions to ask first.
If someone's Value Map showed high conflict around "Investment" spending,
the profiling engine prioritises asking about their goals and aspirations.
```

#### Session 7: Function Calling + Tools (Day 10-12)
```
Largely unchanged from original plan.
Added: Tools include value_category operations.
- get_value_breakdown: returns Foundation/Burden/Investment/Leak split
- compare_values_vs_perception: The Gap analysis on demand
- suggest_value_recategorisation: "Based on your patterns, should X be Foundation or Leak?"
```

#### Session 8: Monthly Review (Day 12-13)
```
Added: Monthly review includes value category shifts.
"Last month, 62% Foundation / 18% Investment / 12% Leak / 8% Burden.
This month, Foundation dropped to 55% and Leak increased to 19%.
That shift happened mostly in dining — you went from 70% Investment
(intentional meals) to 50% Leak (impulse spending). What changed?"
```

#### Sessions 9-13: Unchanged from original plan (Day 13-20)
```
Bill optimisation, trip planning, scenario modelling,
nudge system, profile transparency, polish and deploy.
```

---

### 6. The Gap — Feature Specification

This is the feature that no other finance app has. It deserves its own specification.

**What it is:** A comparison between the user's self-reported relationship with money (from the Value Map) and their actual spending behavior (from CSV data).

**When it appears:**
- First time: immediately after the first CSV upload (if Value Map was completed)
- Ongoing: in monthly reviews, when value category patterns shift
- On demand: "Show me my gap" in chat

**What it looks like:**

```
THE GAP — What you believe vs what you do

You said gym is an Investment (confidence: 3/5)
→ Reality: You spent €0 on fitness last month. Your last gym charge was 47 days ago.

You said coffee is Foundation (confidence: 5/5)  
→ Reality: €87 on coffee shops this month. It IS your foundation — you weren't wrong.

You said Deliveroo is a Leak (confidence: 5/5)
→ Reality: €0 on delivery apps. You've already eliminated this leak. Well done.

You said dining is an Investment
→ Reality: 21 dining transactions, but 14 were under €12 (quick/solo meals).
   Only 7 were the intentional, relationship-building meals you had in mind.
   Your "Investment" dining is actually 33% Investment, 67% Foundation.
```

**Why it matters:** This is the behavioral insight layer that no spreadsheet or dashboard can provide. It holds up a mirror and says "here's who you think you are with money, and here's who you actually are." That gap is where all the meaningful financial advice lives.

**Technical implementation:**
1. Store Value Map categorizations and confidence scores
2. After CSV import, map real transactions to Value Map categories
3. Compare patterns: frequency, amount, trend direction
4. Claude generates the narrative comparison
5. Insights stored in financial_portrait with source: 'gap_analysis'

---

### 7. Product Metrics to Track

**Activation:**
- Value Map completion rate
- Value Map → signup conversion rate
- Time to first CSV upload
- Time to first aha moment

**Engagement:**
- Monthly active conversations
- CSV uploads per month
- Value category corrections (signals engagement with the framework)
- Action items completed vs created

**Retention:**
- Monthly review completion rate
- Week-over-week chat sessions
- Profile completeness over time
- Nudge open/action rate

**Trust (the most important):**
- Profile corrections per session (initially high = good, they're refining; later high = bad, we're wrong)
- "What Claude knows about me" page visits
- Data deletion requests (should be near zero)
- Value category re-categorisation frequency (some is healthy engagement, too much means the system is wrong)
