# CLAUDE.md — The CFO's Office

## What This Is

A trust-first personal finance advisor that combines chat (Claude via Bedrock) with a structured dashboard to help users understand and optimise their financial lives. Users share data gradually through conversation and CSV uploads, receiving increasingly personalised advice powered by an AI "CFO" that knows their numbers, understands their psychology, and gives honest strategic advice.

The product name is **The CFO's Office**. The metaphor: walking into a startup CFO's office for a chat about your personal finances.

## V1 Reference

The previous version of this app lives at `../cfo-v1`. It was built on the same stack (Next.js + Supabase + Vercel) but the codebase and database grew organically and became messy. The core features work — CSV parsing, chat with Claude, dashboard, auth, transaction categorisation — but need refactoring into the clean architecture defined here.

**For each feature you build:**
1. Check if equivalent code exists in `../cfo-v1`
2. Read the v1 implementation to understand the working logic
3. If the file is clean and aligns with this architecture → copy and adapt
4. If the logic is right but the code is tangled → rewrite using v1 as reference
5. If the feature is new (dual categorisation, Value Map integration, progressive profiling) → build fresh

**Never blindly copy v1 code.** The schema is different, the architecture is different, and the patterns should be cleaner. Use v1 as a reference for business logic, not as a template.

---

## Architecture

```
Frontend:  Next.js App Router on Vercel
Auth:      Supabase Auth (email + Google OAuth)
Database:  Supabase PostgreSQL with RLS
Storage:   Supabase Storage (CSV uploads, bill images)
Chat:      Vercel AI SDK (@ai-sdk/amazon-bedrock) → Claude Sonnet 4.6
Background: Supabase Edge Functions + pg_cron
Styling:   Tailwind CSS
```

### Core Architectural Rule

**The LLM interprets. The system computes.**

Claude never does arithmetic, date calculations, budget tracking, or financial projections in its head. All numbers are computed by Edge Functions or SQL queries and injected into Claude's context as structured data. Claude's job is to understand the user, explain the numbers, and give personalised advice.

When Claude needs a calculation, it calls a tool. The tool executes against the database and returns the result. Claude then presents and interprets that result.

---

## Design Principles

These are not aspirational. They are implementation constraints.

### 1. Ask late, ask little
- Registration is email + password only. Nothing else.
- Profile fields are nullable. They populate over time through conversation.
- The profiling engine suggests 1-2 questions per conversation, never more.
- Questions only appear when contextually relevant.
- If the conversation doesn't naturally lead to a question, don't force it.

### 2. Deliver value before depth
- The first "aha moment" happens within 5 minutes of CSV upload.
- The Value Map delivers value before signup even happens.
- Every conversation should leave the user with at least one actionable insight.
- Don't gate value behind data collection. Show what you can with what you have.

### 3. Be explicit about why data is needed
- Every structured input shows a rationale: why this is asked and what it unlocks.
- In chat, Claude explains what answering a question enables.
- The profile page shows what's known, what's missing, and what each gap costs in advice quality.

### 4. Don't rely on the LLM alone
- Financial calculations: Edge Functions, not Claude.
- Transaction categorisation: rules engine first, LLM fallback.
- Profile updates from conversation: validated before saving.
- Budget alerts and bill monitoring: system-computed cron jobs.
- Claude's function calls are validated server-side before writing to the database.

### 5. Make every interaction trust-building
- Users can always see and edit what the system knows about them.
- Confidence scores are visible where the system infers data.
- Claude acknowledges uncertainty. "Based on 3 months of data" not "your spending is..."
- Every correction makes the system more accurate. Corrections are easy and encouraged.

---

## Tech Stack Details

### Bedrock Configuration

```typescript
// lib/ai/provider.ts
import { createAmazonBedrock } from '@ai-sdk/amazon-bedrock';

export const bedrock = createAmazonBedrock({
  region: process.env.AWS_REGION!,
  accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
});

export const chatModel = bedrock('anthropic.claude-sonnet-4-6-20250514-v1:0');
```

### Environment Variables Required

```
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# AWS Bedrock
AWS_REGION=
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=

# App
NEXT_PUBLIC_APP_URL=
```

---

## Key Concepts

### Dual Categorisation

Every transaction gets TWO classifications:

**Traditional category** (objective, auto-assigned):
Groceries, Dining, Transport, Travel, Entertainment, Shopping, Health, Bills, etc.
Assigned by rules engine (pattern matching on description), with LLM fallback for unmatched.
Used for: budget tracking, month-over-month comparison, spending breakdown.

**Value category** (subjective, user-influenced):
- **Foundation**: essential to daily functioning
- **Burden**: necessary but resented
- **Investment**: builds future value (financial, personal, relational)
- **Leak**: wasteful or regretted
- **Unclassified**: not yet categorised

Value categories are initially seeded from the Value Map (if the user completed it), then refined through user interaction. The dashboard toggles between "Spending View" (traditional) and "Values View" (Foundation/Burden/Investment/Leak).

### The Value Map

A pre-signup experience at /demo. The user categorises 10 sample transactions into Foundation/Burden/Investment/Leak/Don't Know, with a confidence rating. The system also tracks decision time and changes of mind.

The results are sent to Claude which generates a personality archetype (e.g. "The Drifter — your money moves without a plan") with a detailed analysis of what the categorisation patterns reveal about their relationship with money.

**Integration flow:**
1. User completes Value Map (no account required)
2. Results stored with anonymous session ID
3. User signs up → session linked to account
4. Value Map results seed: financial_portrait, value_category_rules
5. After CSV upload → "The Gap" analysis compares self-perception with reality

### The Gap

The killer feature. Compares what users believe about their spending (from Value Map) with what their actual transactions show.

Example: "You called gym spending an Investment (confidence 3/5). Reality: you haven't been charged by a gym in 47 days."

This appears after the first CSV upload (if Value Map was completed), in monthly reviews when patterns shift, and on demand in chat.

### Progressive Profiling

A priority queue that determines which profile questions to ask and when. See the full specification in the intelligence layer document. Key rules:
- Maximum 1-2 questions per conversation
- Questions have triggers (context keywords, dependencies, minimum conversation count)
- Three input methods: structured (inline components), conversational (Claude function calling), inferred (Claude extracts from natural speech)
- Confidence thresholds determine auto-save vs confirmation vs explicit ask

### The CFO Persona

Direct, knowledgeable, strategic. Knows the user's numbers. Pushes back when needed. Remembers everything. Adjusts tone based on user preference (gentle/direct/blunt). A CFO advises — they don't decide for you.

Key persona rules:
- Use actual numbers, not generic ranges
- Never lecture — explain once, then move to action
- When spending contradicts values, name it without judgement
- Acknowledge limitations honestly (not a licensed advisor, can't do tax)
- Reference past conversations naturally

---

## Database Schema

### Core Tables

```sql
-- Users and profiles (progressive, mostly nullable)
create table user_profiles (
  id uuid primary key references auth.users(id),
  display_name text,
  country text,
  city text,
  primary_currency text default 'EUR',
  age_range text,
  employment_status text,
  gross_salary numeric,
  net_monthly_income numeric,
  pay_frequency text default 'monthly',
  has_bonus_months boolean,
  bonus_month_details jsonb,
  housing_type text,
  monthly_rent numeric,
  relationship_status text,
  partner_employment_status text,
  partner_monthly_contribution numeric,
  dependents integer default 0,
  values_ranking jsonb,
  spending_triggers jsonb,
  risk_tolerance text,
  financial_awareness text,
  advice_style text default 'direct',
  nationality text,
  residency_status text,
  tax_residency_country text,
  years_in_country integer,
  onboarding_completed_at timestamptz,
  profile_completeness integer default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Financial accounts
create table accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  name text not null,
  type text not null,
  provider text,
  currency text default 'EUR',
  current_balance numeric,
  is_primary_spending boolean default false,
  metadata jsonb,
  created_at timestamptz default now()
);

-- Transactions with dual categorisation
create table transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  account_id uuid references accounts(id),
  date timestamptz not null,
  description text not null,
  amount numeric not null,
  currency text default 'EUR',
  category_id uuid references categories(id),
  auto_category_confidence numeric,
  user_confirmed boolean default false,
  value_category text,
  is_recurring boolean default false,
  is_shared_expense boolean default false,
  is_holiday_spend boolean default false,
  tags text[],
  notes text,
  source text,
  import_batch_id uuid,
  raw_description text,
  created_at timestamptz default now()
);

-- Traditional spending categories
create table categories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  name text not null,
  icon text,
  color text,
  monthly_budget numeric,
  is_fixed boolean default false,
  is_essential boolean default true,
  sort_order integer,
  matching_rules jsonb
);

-- Recurring bills and expenses
create table recurring_expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  account_id uuid references accounts(id),
  category_id uuid references categories(id),
  name text not null,
  provider text,
  amount numeric not null,
  currency text default 'EUR',
  frequency text not null,
  billing_day integer,
  current_plan_details jsonb,
  contract_end_date date,
  has_permanencia boolean default false,
  last_optimisation_check timestamptz,
  potential_saving_monthly numeric,
  switch_recommendation text,
  created_at timestamptz default now()
);

-- Financial goals
create table goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  name text not null,
  description text,
  target_amount numeric,
  current_amount numeric default 0,
  target_date date,
  priority text,
  status text default 'active',
  monthly_required_saving numeric,
  on_track boolean,
  created_at timestamptz default now()
);

-- Investment holdings
create table investment_holdings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  account_id uuid references accounts(id),
  ticker text,
  name text not null,
  asset_type text,
  quantity numeric,
  current_value numeric,
  cost_basis numeric,
  currency text default 'GBP',
  gain_loss_pct numeric,
  allocation_pct numeric,
  last_updated timestamptz default now()
);

-- Chat conversations
create table conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  title text,
  type text default 'general',
  status text default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Chat messages
create table messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references conversations(id) on delete cascade,
  role text not null,
  content text not null,
  profile_updates jsonb,
  actions_created jsonb,
  insights_generated jsonb,
  tools_used text[],
  created_at timestamptz default now()
);

-- Action items
create table action_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  conversation_id uuid references conversations(id),
  title text not null,
  description text,
  category text,
  priority text,
  status text default 'pending',
  due_date date,
  last_nudge_at timestamptz,
  nudge_count integer default 0,
  completed_at timestamptz,
  created_at timestamptz default now()
);

-- System-computed monthly snapshots
create table monthly_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  month date not null,
  total_income numeric,
  total_fixed_costs numeric,
  total_discretionary numeric,
  total_spending numeric,
  surplus_deficit numeric,
  spending_by_category jsonb,
  spending_by_value_category jsonb,
  transaction_count integer,
  dining_out_count integer,
  avg_transaction_size numeric,
  largest_transaction numeric,
  largest_transaction_desc text,
  vs_previous_month_pct numeric,
  vs_budget_pct numeric,
  created_at timestamptz default now(),
  unique(user_id, month)
);

-- Financial portrait (behavioral insights)
create table financial_portrait (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  trait_type text not null,
  trait_key text not null,
  trait_value text not null,
  confidence numeric default 0.5,
  evidence text,
  source_conversation_id uuid references conversations(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique(user_id, trait_key)
);

-- Value Map results
create table value_map_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  session_id text,
  responses jsonb not null,
  archetype_name text,
  archetype_subtitle text,
  full_analysis text,
  certainty_areas jsonb,
  conflict_areas jsonb,
  comfort_patterns jsonb,
  country text,
  completed_at timestamptz default now(),
  created_at timestamptz default now()
);

-- Value category mapping rules
create table value_category_rules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  match_type text not null,
  match_value text not null,
  value_category text not null,
  confidence numeric default 0.5,
  source text,
  created_at timestamptz default now()
);

-- Nudges and notifications
create table nudges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text not null,
  action_url text,
  trigger_rule jsonb,
  status text default 'pending',
  scheduled_for timestamptz,
  sent_at timestamptz,
  read_at timestamptz,
  created_at timestamptz default now()
);
```

### Row Level Security

Apply to ALL user-scoped tables:

```sql
alter table [table_name] enable row level security;

create policy "Users can view own data" on [table_name]
  for select using (auth.uid() = user_id);

create policy "Users can insert own data" on [table_name]
  for insert with check (auth.uid() = user_id);

create policy "Users can update own data" on [table_name]
  for update using (auth.uid() = user_id);

create policy "Users can delete own data" on [table_name]
  for delete using (auth.uid() = user_id);
```

For `user_profiles`, use `id` instead of `user_id`:
```sql
create policy "Users can view own profile" on user_profiles
  for select using (auth.uid() = id);
```

### Indexes

```sql
create index idx_transactions_user_date on transactions(user_id, date desc);
create index idx_transactions_user_category on transactions(user_id, category_id);
create index idx_transactions_user_value on transactions(user_id, value_category);
create index idx_messages_conversation on messages(conversation_id, created_at);
create index idx_monthly_snapshots_user on monthly_snapshots(user_id, month desc);
create index idx_action_items_user_status on action_items(user_id, status);
create index idx_nudges_user_status on nudges(user_id, status, scheduled_for);
```

### Triggers

```sql
-- Auto-create profile on user signup
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into user_profiles (id)
  values (new.id);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- Insert default categories for new users
create or replace function create_default_categories()
returns trigger as $$
begin
  insert into categories (user_id, name, icon, color, is_fixed, is_essential, sort_order, matching_rules)
  values
    (new.id, 'Groceries', '🛒', '#1D9E75', false, true, 1, '["aldi","mercadona","caprabo","carrefour","lidl","condis","primaprix","spar"]'::jsonb),
    (new.id, 'Dining & Bars', '🍽️', '#D85A30', false, false, 2, '["restaurant","bar ","cafe","café","pub","pizza","kebab","burger","sushi","tapas"]'::jsonb),
    (new.id, 'Transport', '🚌', '#534AB7', false, true, 3, '["metro","bus","taxi","bolt","cabify","uber","renfe","train"]'::jsonb),
    (new.id, 'Travel', '✈️', '#E24B4A', false, false, 4, '["ryanair","easyjet","iberia","vueling","booking.com","airbnb","hotel","hostel"]'::jsonb),
    (new.id, 'Entertainment', '🎬', '#D4537E', false, false, 5, '["cinema","cine","netflix","spotify","concert","festival","ticket"]'::jsonb),
    (new.id, 'Shopping', '🛍️', '#BA7517', false, false, 6, '["amazon","zara","apple","el corte","primark","mango"]'::jsonb),
    (new.id, 'Health', '💊', '#378ADD', false, true, 7, '["farmacia","pharmacy","sanitas","doctor","gym","fitness"]'::jsonb),
    (new.id, 'Bills & Utilities', '📄', '#888780', true, true, 8, '["iberdrola","digi","vodafone","movistar","aigues","agua","electric","gas"]'::jsonb),
    (new.id, 'Subscriptions', '🔄', '#639922', true, false, 9, '["spotify","netflix","hbo","disney","revolut","apple music"]'::jsonb),
    (new.id, 'Other', '📦', '#5F5E5A', false, false, 10, null);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_profile_created
  after insert on user_profiles
  for each row execute function create_default_categories();

-- Update profile completeness on profile change
create or replace function update_profile_completeness()
returns trigger as $$
declare
  total_fields integer := 15;
  filled_fields integer := 0;
begin
  if new.display_name is not null then filled_fields := filled_fields + 1; end if;
  if new.country is not null then filled_fields := filled_fields + 1; end if;
  if new.city is not null then filled_fields := filled_fields + 1; end if;
  if new.age_range is not null then filled_fields := filled_fields + 1; end if;
  if new.employment_status is not null then filled_fields := filled_fields + 1; end if;
  if new.net_monthly_income is not null then filled_fields := filled_fields + 1; end if;
  if new.housing_type is not null then filled_fields := filled_fields + 1; end if;
  if new.monthly_rent is not null then filled_fields := filled_fields + 1; end if;
  if new.relationship_status is not null then filled_fields := filled_fields + 1; end if;
  if new.values_ranking is not null then filled_fields := filled_fields + 1; end if;
  if new.spending_triggers is not null then filled_fields := filled_fields + 1; end if;
  if new.risk_tolerance is not null then filled_fields := filled_fields + 1; end if;
  if new.advice_style is not null then filled_fields := filled_fields + 1; end if;
  if new.nationality is not null then filled_fields := filled_fields + 1; end if;
  if new.has_bonus_months is not null then filled_fields := filled_fields + 1; end if;
  
  new.profile_completeness := round((filled_fields::numeric / total_fields) * 100);
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

create trigger before_profile_update
  before update on user_profiles
  for each row execute function update_profile_completeness();
```

---

## File Structure

```
/app
  /api
    /chat/route.ts                    # Vercel AI SDK chat handler with Bedrock
    /upload/route.ts                  # CSV upload + parse + categorise
    /tools/[tool]/route.ts            # Claude function call execution
    /cron/daily/route.ts              # Daily nudge check
    /cron/monthly/route.ts            # Monthly snapshot generation
  /(public)
    /demo/page.tsx                    # Value Map (pre-signup)
    /demo/result/page.tsx             # Value Map personality result
  /(auth)
    /login/page.tsx
    /signup/page.tsx
  /(app)
    /layout.tsx                       # Authenticated layout with sidebar nav
    /chat/page.tsx                    # New conversation
    /chat/[id]/page.tsx               # Existing conversation
    /dashboard/page.tsx               # Financial overview (dual view toggle)
    /transactions/page.tsx            # Transaction list with filters
    /bills/page.tsx                   # Recurring expenses + optimisation
    /goals/page.tsx                   # Goal tracker
    /profile/page.tsx                 # "What your CFO knows" — view/edit profile
    /settings/page.tsx                # Preferences, data management, export
/lib
  /ai
    /provider.ts                      # Bedrock client setup
    /system-prompt.ts                 # Base CFO persona
    /context-builder.ts               # Assembles dynamic system prompt
    /tools.ts                         # Claude tool definitions
    /tool-executor.ts                 # Validates and executes tool calls
  /profiling
    /question-registry.ts             # All profile questions with metadata
    /engine.ts                        # Priority queue logic
  /parsers
    /index.ts                         # Format auto-detection
    /revolut.ts                       # Revolut CSV parser
    /santander.ts                     # Santander XLSX parser (Spanish format)
    /generic.ts                       # Generic CSV with column mapping
  /categorizer
    /rules-engine.ts                  # Pattern-matching categorisation
    /llm-categorizer.ts              # Claude fallback for unmatched
    /value-categorizer.ts             # Value category assignment
  /analytics
    /monthly-snapshot.ts              # Compute monthly summary
    /recurring-detector.ts            # Find recurring transactions
    /holiday-detector.ts              # Cluster foreign merchant spending
    /gap-analyser.ts                  # Compare Value Map vs actual spending
  /nudges
    /rules.ts                         # Nudge trigger definitions
    /scheduler.ts                     # Evaluation and scheduling logic
  /supabase
    /client.ts                        # Supabase client (browser + server)
    /queries.ts                       # Reusable query functions
    /types.ts                         # Generated from schema
/components
  /chat
    /ChatInterface.tsx                # Main chat container
    /MessageBubble.tsx                # User and assistant messages
    /StructuredInput.tsx              # Inline form components in chat
    /ConversationList.tsx             # Sidebar conversation history
  /dashboard
    /SpendingView.tsx                 # Traditional category breakdown
    /ValuesView.tsx                   # Foundation/Burden/Investment/Leak view
    /MonthlyCards.tsx                 # Summary metric cards
    /TrendChart.tsx                   # Spending over time
    /ViewToggle.tsx                   # Switch between Spending/Values
  /transactions
    /TransactionList.tsx
    /CategoryBadge.tsx                # Traditional category pill
    /ValueBadge.tsx                   # Value category pill
    /RecategoriseModal.tsx            # Change category (both types)
  /upload
    /CSVUploader.tsx                  # Drag-and-drop with format detection
    /TransactionPreview.tsx           # Preview before confirming import
  /profile
    /ProfileCard.tsx                  # Grouped profile fields
    /TraitDisplay.tsx                 # Financial portrait traits
    /CompletenessIndicator.tsx        # Visual progress
    /EditableField.tsx                # Inline edit any field
  /value-map
    /ValueMapFlow.tsx                 # The 10-transaction experience
    /ArchetypeResult.tsx              # Personality reading display
    /TransactionCard.tsx              # Individual transaction to categorise
/supabase
  /migrations
    /001_initial_schema.sql
    /002_rls_policies.sql
    /003_indexes.sql
    /004_triggers_and_functions.sql
    /005_seed_data.sql
```

---

## System Prompt Architecture

The system prompt is assembled dynamically per conversation. See `lib/ai/context-builder.ts`.

### Assembly Order

```
1. Base CFO persona (always included, ~300 tokens)
2. Profile context — what we know about this user (~200 tokens)
3. Financial summary — system-computed numbers (~400 tokens)
4. Financial portrait — behavioral traits + Value Map (~300 tokens)
5. Goals and action items (~200 tokens)
6. Profiling questions — what to ask if natural (~150 tokens)
7. Conversation type instructions (~200 tokens)
```

### Critical Instructions in System Prompt

```
IMPORTANT RULES:
- Always use the system-provided financial numbers. Never calculate yourself.
- If you need a number that isn't provided, call the appropriate tool.
- When the user shares personal or financial information, call update_user_profile
  to store it. Always confirm what you've noted.
- Maximum 1-2 profile questions per conversation. Don't force them.
- Use the request_structured_input tool when you need precise numeric data.
- Reference the user's Value Map archetype and traits naturally, don't list them.
- When spending contradicts their stated values, name it without judgement.
```

### Tool Definitions

```typescript
const tools = {
  update_user_profile: {
    description: "Update the user's profile when they share relevant information. Call this whenever they mention income, expenses, living situation, relationships, goals, or preferences. Validate with the user what you've noted.",
    parameters: {
      updates: "Array of {field, value, confidence} objects",
      source_summary: "Brief description of what the user said"
    }
  },
  
  request_structured_input: {
    description: "Ask for specific data using an appropriate input component (number, select, slider, currency amount). Use this for critical numeric data where precision matters.",
    parameters: {
      field: "Profile field name",
      input_type: "currency_amount | single_select | multi_select | number | slider",
      label: "Question to display",
      options: "For select types: array of options",
      rationale: "Why this is needed (shown to user)",
      validation: "Min/max/required constraints"
    }
  },
  
  get_spending_summary: {
    description: "Get spending data for a date range, optionally filtered by category.",
    parameters: {
      date_from: "Start date",
      date_to: "End date",
      category: "Optional traditional category filter",
      value_category: "Optional value category filter"
    }
  },
  
  compare_months: {
    description: "Compare spending between two months.",
    parameters: { month_a: "YYYY-MM", month_b: "YYYY-MM" }
  },
  
  get_value_breakdown: {
    description: "Get the Foundation/Burden/Investment/Leak breakdown for a period.",
    parameters: { date_from: "Start date", date_to: "End date" }
  },
  
  model_scenario: {
    description: "Model a financial what-if scenario.",
    parameters: {
      scenario_type: "salary_increase | property_purchase | children | career_change | investment_growth",
      parameters: "Scenario-specific parameters"
    }
  },
  
  search_bill_alternatives: {
    description: "Research better deals for a recurring bill.",
    parameters: {
      bill_type: "electricity | gas | internet | phone | insurance",
      current_provider: "Provider name",
      current_amount: "Monthly cost",
      usage_details: "kWh, speed, plan details"
    }
  },
  
  create_action_item: {
    description: "Create a tracked action item for the user.",
    parameters: {
      title: "Action title",
      description: "Details",
      category: "bill_switch | savings_transfer | investment | admin | research",
      priority: "high | medium | low",
      due_date: "Optional due date"
    }
  },
  
  analyse_gap: {
    description: "Compare Value Map self-perception with actual spending data.",
    parameters: { months: "Number of months of data to analyse" }
  }
};
```

---

## Data Extraction from Conversation

Three channels with different reliability:

### Channel A: Structured Inputs (Highest Reliability)
For critical numeric data. Claude calls `request_structured_input` → frontend renders inline component → user submits → writes to DB immediately.

Use for: salary, rent, bill amounts, age range, currency, country.

### Channel B: Function Calling (Medium Reliability)  
Claude calls `update_user_profile` when it detects relevant information in conversation.

Validation rules:
- Confidence > 0.8: auto-save, mention naturally in response
- Confidence 0.6-0.8: save but confirm with user
- Confidence < 0.6: don't save, ask explicitly
- Never silently overwrite a user-confirmed value with an inferred one

Use for: relationship status, employment details, behavioral observations, preferences.

### Channel C: Post-Conversation Analysis (Supplementary)
Edge Function runs after conversation ends. Sends transcript to Claude for behavioral trait extraction. Results written to financial_portrait.

Use for: spending patterns, behavioral traits, value shifts, contradictions.

---

## CSV Parsing

### Format Detection

Check the first row to determine format:
- Headers include "Type,Started Date,Completed Date,Description,Amount,Fee,Balance" → Revolut
- File is .xlsx with Spanish-formatted numbers (period thousands, comma decimals) → Santander  
- Otherwise → show column mapping UI

### Categorisation Pipeline

```
1. Clean description (trim, lowercase for matching)
2. Check user's custom rules (value_category_rules table)
3. Check category matching_rules (pattern match)
4. If matched with high confidence → assign
5. If unmatched → batch and send to Claude for categorisation
6. For value categories: check value_category_rules, fall back to null
7. Return categorised transactions for user preview before saving
```

### Important Parsing Notes (from v1 experience)

- Santander uses `−` (en-dash minus, U+2212) not `-` (hyphen) for negative amounts
- Santander uses period as thousands separator, comma as decimal: "1.457,69"
- Revolut amounts are already signed (negative = outflow)
- Always deduplicate on (date + amount + description) to handle re-uploads
- Bimonthly bills (gas, water) should be flagged — don't double-count

---

## Session Implementation Order

### Session 1: Foundation + Value Map (Day 1-2)
New project, schema, auth, layout, Value Map integration from v1.

### Session 2: Chat on Bedrock (Day 2-3)
Vercel AI SDK + Bedrock streaming, conversation persistence, system prompt.

### Session 3: CSV + Dual Categorisation (Day 3-5)
Port parsers, build categorisation pipeline with both category types.

### Session 4: The Aha Moment + The Gap (Day 5-6)
Post-CSV analysis, Value Map comparison, first profile seeding.

### Session 5: Dashboard with Dual Views (Day 6-8)
Spending View + Values View, charts, transaction list.

### Session 6: Progressive Profiling (Day 8-10)
Question registry, profiling engine, structured inputs in chat.

### Session 7: Function Calling + Tools (Day 10-12)
All Claude tools, validation layer, tool execution.

### Session 8: Monthly Review (Day 12-13)
Structured review flow with value category shifts.

### Session 9: Bill Optimisation (Day 13-15)
Recurring expense detection, bill upload, alternative research.

### Session 10: Trip Planning + Scenarios (Day 15-17)
Trip budgeting, scenario modelling, web search integration.

### Session 11: Nudge System (Day 17-19)
Rules engine, scheduled jobs, delivery.

### Session 12: Profile Transparency (Day 19-20)
"What your CFO knows" page, edit/delete, data export.

### Session 13: Polish + Deploy (Day 20-22)
Error handling, performance, security review, seed user #1 data.

---

## Common Pitfalls (Learned from v1)

1. **Don't let Claude do maths.** It will get cash flow wrong. Every number comes from a query or Edge Function.

2. **Don't assume billing frequency.** Gas and water in Spain are often bimonthly. Always check and flag.

3. **Santander number format is treacherous.** `1.457,69` means one thousand four hundred fifty-seven euros and sixty-nine cents. Parse carefully.

4. **The Santander minus sign isn't a hyphen.** It's U+2212. Replace before parsing.

5. **Save data progressively.** If a form or chat collects 5 pieces of data, save each one as it's confirmed. Never wait for a "submit all" action.

6. **Don't over-collect upfront.** The impulse is to ask everything during onboarding. Resist it. Ask late, ask little. A profile that fills up over 5 conversations is better than an onboarding wall that users abandon.

7. **The LLM will confidently extract wrong data.** Always validate. A confidence threshold below 0.6 should trigger an explicit question, not a silent save.

8. **Holiday spending distorts averages.** Tag foreign merchant clusters as holiday spending and show baseline vs holiday spending separately.

9. **Credit card liquidation payments are not spending.** When parsing Santander, filter out "LIQUIDACION DE LAS TARJETAS DE CREDITO" — this is paying off Revolut, not separate spending.

10. **Token budget is real.** A fully populated profile + 6 months of snapshots + portrait + goals can easily hit 4000+ tokens of context. Prioritise ruthlessly. Current month data > historical. Active goals > completed.
