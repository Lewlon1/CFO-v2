import { useState } from "react";

const BEFORE_AFTER = [
  { name: "Budget & cash flow", before: 85, after: 90, category: "everyday", delta: "6 months of Revolut data, trip vs baseline patterns, behavioral triggers confirmed" },
  { name: "Recurring payments", before: 80, after: 93, category: "everyday", delta: "Actual Digi and Iberdrola bills with plan details, kWh, potencia, contract dates. Identified electricity overcharge." },
  { name: "Foundational spending", before: 60, after: 70, category: "everyday", delta: "More data on grocery frequency and stores. Still missing: what you buy, meal habits, brand flexibility." },
  { name: "Goals & targets", before: 75, after: 78, category: "planning", delta: "Better life context (girlfriend, openness to moving). But 'part-time at 40' still needs concrete numbers." },
  { name: "Trip planning", before: 70, after: 80, category: "planning", delta: "6 months shows Sicily, France, ski, UK, US trips. Know it includes family visits. Girlfriend is American (US trips likely regular)." },
  { name: "Scenario modelling", before: 80, after: 88, category: "planning", delta: "Complete ISA breakdown, crypto details, pension structure, potential UK remote salary uplift." },
  { name: "Investment strategy", before: 55, after: 85, category: "investing", delta: "Biggest jump. Full HL portfolio visible — concentration risk, uninvested cash, active picker profile, gilt positions, altcoin losses." },
  { name: "Tax optimisation", before: 30, after: 42, category: "investing", delta: "Know NIE status, TIE timeline, ISA structure. Still need TaxDown history and a specialist consultation." },
  { name: "Government initiatives", before: 40, after: 52, category: "investing", delta: "Know residency timeline (5 years next summer). Can research TIE-specific benefits. Still need specialist input." },
  { name: "Life events", before: 45, after: 62, category: "life", delta: "Girlfriend American, kids when stable, no property plans, open to relocation, parents comfortable. Much clearer picture." },
  { name: "Emergency preparedness", before: 65, after: 75, category: "life", delta: "Confirmed no emergency fund, no income protection, no contents insurance. £11.8k in ISA is only accessible buffer." },
  { name: "Action follow-ups", before: 70, after: 73, category: "ongoing", delta: "Know he wants direct and blunt. Need to establish monthly rhythm." },
  { name: "Monthly review", before: 75, after: 86, category: "ongoing", delta: "6-month baseline established. Know seasonal patterns, trip impact, credit card cycle." },
  { name: "Spending intelligence", before: 50, after: 62, category: "ongoing", delta: "Have all bill details for comparison shopping. Electricity contract ends June — actionable deadline." },
];

const CATEGORY_COLORS = {
  everyday: "#1D9E75",
  planning: "#378ADD",
  investing: "#534AB7",
  life: "#D85A30",
  ongoing: "#BA7517",
};

const CATEGORY_LABELS = {
  everyday: "Everyday",
  planning: "Planning",
  investing: "Investing",
  life: "Life events",
  ongoing: "Ongoing",
};

export default function ConfidenceUpdate() {
  const [expanded, setExpanded] = useState(null);

  const avgBefore = Math.round(BEFORE_AFTER.reduce((s, i) => s + i.before, 0) / BEFORE_AFTER.length);
  const avgAfter = Math.round(BEFORE_AFTER.reduce((s, i) => s + i.after, 0) / BEFORE_AFTER.length);
  const totalGain = avgAfter - avgBefore;

  const remaining = BEFORE_AFTER.filter(i => i.after < 80);
  const strong = BEFORE_AFTER.filter(i => i.after >= 80);

  return (
    <div style={{ maxWidth: 660, margin: "0 auto", padding: "0.5rem 0" }}>
      <div style={{ display: "flex", gap: 10, marginBottom: "1.5rem" }}>
        <div style={{ flex: 1, background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: "14px", textAlign: "center" }}>
          <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 2 }}>Before today</div>
          <div style={{ fontSize: 24, fontWeight: 500, color: "#BA7517" }}>{avgBefore}%</div>
        </div>
        <div style={{ flex: 1, background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: "14px", textAlign: "center" }}>
          <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 2 }}>After today</div>
          <div style={{ fontSize: 24, fontWeight: 500, color: "#1D9E75" }}>{avgAfter}%</div>
        </div>
        <div style={{ flex: 1, background: "var(--color-background-success)", borderRadius: "var(--border-radius-md)", padding: "14px", textAlign: "center" }}>
          <div style={{ fontSize: 11, color: "var(--color-text-success)", marginBottom: 2 }}>Improvement</div>
          <div style={{ fontSize: 24, fontWeight: 500, color: "var(--color-text-success)" }}>+{totalGain}pp</div>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {BEFORE_AFTER.map((item, i) => {
          const color = CATEGORY_COLORS[item.category];
          const isOpen = expanded === i;
          const gain = item.after - item.before;
          return (
            <div key={i} onClick={() => setExpanded(isOpen ? null : i)} style={{
              background: "var(--color-background-primary)",
              border: "0.5px solid var(--color-border-tertiary)",
              borderRadius: "var(--border-radius-md)",
              overflow: "hidden",
              cursor: "pointer",
            }}>
              <div style={{ padding: "10px 14px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: color, flexShrink: 0 }} />
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{item.name}</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>{item.before}%</span>
                    <span style={{ fontSize: 12 }}>→</span>
                    <span style={{ fontSize: 13, fontWeight: 500, color: item.after >= 80 ? "#1D9E75" : item.after >= 60 ? "#BA7517" : "#E24B4A" }}>{item.after}%</span>
                    <span style={{ fontSize: 11, color: "#1D9E75", minWidth: 32 }}>+{gain}</span>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 4, height: 4, borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ width: `${item.before}%`, height: "100%", background: "var(--color-border-secondary)", borderRadius: 2, transition: "width 0.4s" }} />
                  <div style={{ width: `${item.after - item.before}%`, height: "100%", background: color, borderRadius: 2, transition: "width 0.4s" }} />
                </div>
              </div>
              {isOpen && (
                <div style={{ padding: "0 14px 12px", borderTop: "0.5px solid var(--color-border-tertiary)", marginTop: 4, paddingTop: 10 }}>
                  <div style={{ fontSize: 12, color: "var(--color-text-secondary)", lineHeight: 1.7 }}>{item.delta}</div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: "1.5rem", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{
          padding: "14px 16px", background: "var(--color-background-primary)",
          border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)",
        }}>
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 8 }}>Strong confidence (80%+) — {strong.length} situations</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.7 }}>
            {strong.map(s => s.name).join(", ")}. These are ready for full advisory — I have enough data to give you genuinely personalised advice.
          </div>
        </div>

        <div style={{
          padding: "14px 16px", background: "var(--color-background-primary)",
          border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)",
        }}>
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 8 }}>Needs work (below 80%) — {remaining.length} situations</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.7 }}>
            {remaining.map(s => `${s.name} (${s.after}%)`).join(", ")}. Tax and government initiatives will always need specialist input. The others improve with more time and data.
          </div>
        </div>

        <div style={{
          padding: "14px 16px", background: "var(--color-background-secondary)",
          borderRadius: "var(--border-radius-lg)",
        }}>
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 8 }}>Remaining data gaps</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.7 }}>
            1. Girlfriend's contribution to shared costs (affects true disposable income)<br/>
            2. TaxDown filing history (what have you been declaring?)<br/>
            3. Employment contract details (sick pay, redundancy, exact pension terms)<br/>
            4. 6 more months of Revolut history to complete a full year<br/>
            5. Concrete vision for "part-time at 40" with real numbers<br/>
            6. One session with a cross-border tax specialist (UK/Spain)
          </div>
        </div>
      </div>
    </div>
  );
}
